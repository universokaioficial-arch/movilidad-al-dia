// Motor nacional de restricciones. Puro y sin dependencias. NO contiene normas: solo evalúa reglas publicadas.
export type VehicleType = 'automovil'|'motocicleta'|'moto_electrica'|'ciclomotor'|'camioneta'|'camion'|'bus'|'taxi'|'vehiculo_especial'|'otro';
export type Kind = 'pico_placa'|'parrillero'|'tipo_vehiculo'|'zona'|'horario'|'temporal'|'evento'|'ambiental'|'especial';
export type Effect = 'prohibe_circular'|'prohibe_parrillero'|'informativa';
export const KINDS = ['pico_placa','parrillero','tipo_vehiculo','zona','horario','temporal','evento','ambiental','especial'] as const;
export const EFFECTS = ['prohibe_circular','prohibe_parrillero','informativa'] as const;
export const VEHICLE_TYPES = ['automovil','motocicleta','moto_electrica','ciclomotor','camioneta','camion','bus','taxi','vehiculo_especial','otro'] as const;
export interface Win { start: string; end: string }
export interface Zone { name: string; polygon?: [number, number][]; corridors?: string[] }
export interface RuleException { note: string; plates?: string[]; vehicleTypes?: VehicleType[]; fuels?: string[]; dates?: string[]; requiresVerification?: boolean }
export interface MobilityRule {
  id: string; regionId: string; kind: Kind; effect: Effect; name: string;
  status: 'borrador'|'publicada'|'archivada'|'derogada';
  vehicleTypes?: VehicleType[];                       // ausente/vacío = todos
  plateDigit?: 'ultimo'|'penultimo';
  digitsByDate?: Record<string, number[]>;            // calendario explícito YYYY-MM-DD (prioridad 1)
  digitsByParity?: { even: number[]; odd: number[] }; // según día del mes (prioridad 2)
  digitsByDay?: Record<number, number[]>;             // día ISO 1..7 (prioridad 3)
  days?: number[];                                    // reglas sin placa; vacío = todos los días
  windows?: Win[];                                    // vacío = todo el día
  validFrom?: string; validTo?: string;
  zone?: Zone; exceptions?: RuleException[];
  source?: { name: string; url?: string; document?: string; verifiedAt?: string };
  updatedAt?: string; observations?: string;
}
export interface CheckInput {
  date: string; time?: string;                        // sin hora = evaluación de día completo
  regionChain: string[];                              // [municipio, departamento, ...]
  location?: { lat: number; lng: number };
  vehicle: { plate: string; type: VehicleType; fuel?: string; cc?: number };
  withPassenger?: boolean;
}
export type HitState = 'activa'|'aplica_dia'|'fuera_de_horario'|'zona_por_verificar'|'exceptuada'|'excepcion_por_verificar';
export interface Hit { ruleId: string; name: string; kind: Kind; effect: Effect; state: HitState; schedule: Win[]; zone?: Zone; reason: string;
  exception?: string; source?: MobilityRule['source']; updatedAt?: string }
export interface Result { canCirculate: boolean | null; coverage: 'con_reglas'|'sin_reglas'; passengerAllowed: boolean | null; hits: Hit[]; date: string; time?: string }

const toMin = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
export const isoDay = (date: string) => { const d = new Date(date + 'T00:00:00Z').getUTCDay(); return d === 0 ? 7 : d; };
export const addDays = (date: string, n: number) => new Date(Date.parse(date + 'T00:00:00Z') + n * 864e5).toISOString().slice(0, 10);
export function inWindow(wins: Win[] | undefined, time: string): boolean {
  if (!wins?.length) return true; const n = toMin(time);
  return wins.some(w => { const s = toMin(w.start), e = toMin(w.end); return s <= e ? n >= s && n < e : n >= s || n < e; }); // admite 22:00–05:00
}
export function plateDigit(plate: string, which: 'ultimo'|'penultimo' = 'ultimo'): number | null {
  const d = plate.replace(/\D/g, ''); const c = which === 'ultimo' ? d.at(-1) : d.at(-2); return c === undefined ? null : Number(c);
}
export function inPolygon(p: { lat: number; lng: number }, poly: [number, number][]): boolean {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const [yi, xi] = poly[i], [yj, xj] = poly[j];
    if ((yi > p.lat) !== (yj > p.lat) && p.lng < ((xj - xi) * (p.lat - yi)) / (yj - yi) + xi) inside = !inside;
  } return inside;
}
function restrictedDigits(r: MobilityRule, date: string): number[] | null {
  if (r.digitsByDate) { const x = r.digitsByDate[date]; if (x) return x; }
  if (r.digitsByParity) return Number(date.slice(8)) % 2 === 0 ? r.digitsByParity.even : r.digitsByParity.odd;
  if (r.digitsByDay) return r.digitsByDay[isoDay(date)] ?? [];
  return r.digitsByDate ? [] : null;                  // null = la regla no usa placa
}
function matchException(r: MobilityRule, i: CheckInput): RuleException | undefined {
  return r.exceptions?.find(e => {
    const c = [e.plates && e.plates.includes(i.vehicle.plate), e.vehicleTypes && e.vehicleTypes.includes(i.vehicle.type),
      e.fuels && i.vehicle.fuel !== undefined && e.fuels.includes(i.vehicle.fuel), e.dates && e.dates.includes(i.date)].filter(x => x !== undefined);
    return c.length > 0 && c.every(Boolean);
  });
}

export function checkRestrictionsCore(inp: CheckInput, all: MobilityRule[]): Result {
  const rules = all.filter(r => r.status === 'publicada' && inp.regionChain.includes(r.regionId));
  const hits: Hit[] = [];
  for (const r of rules) {
    if ((r.validFrom && inp.date < r.validFrom) || (r.validTo && inp.date > r.validTo)) continue;
    if (r.vehicleTypes?.length && !r.vehicleTypes.includes(inp.vehicle.type)) continue;
    const digits = restrictedDigits(r, inp.date);
    if (digits !== null) { const d = plateDigit(inp.vehicle.plate, r.plateDigit); if (d === null || !digits.includes(d)) continue; }
    else if (r.days?.length && !r.days.includes(isoDay(inp.date))) continue;
    let zoneUnknown = false;
    if (r.zone) {
      if (r.zone.polygon && inp.location) { if (!inPolygon(inp.location, r.zone.polygon)) continue; } else zoneUnknown = true;
    }
    const ex = matchException(r, inp);
    let state: HitState;
    if (ex) state = ex.requiresVerification ? 'excepcion_por_verificar' : 'exceptuada';
    else if (inp.time !== undefined && !inWindow(r.windows, inp.time)) state = 'fuera_de_horario';
    else if (zoneUnknown) state = 'zona_por_verificar';
    else state = inp.time === undefined ? 'aplica_dia' : 'activa';
    hits.push({ ruleId: r.id, name: r.name, kind: r.kind, effect: r.effect, state, schedule: r.windows ?? [], zone: r.zone,
      reason: r.observations ?? `Aplica la regla "${r.name}" (${r.kind.replace('_', ' ')}).`, exception: ex?.note, source: r.source, updatedAt: r.updatedAt });
  }
  const live = (h: Hit) => h.state === 'activa' || h.state === 'aplica_dia';
  const pending = (h: Hit) => h.state === 'zona_por_verificar' || h.state === 'excepcion_por_verificar';
  const circ = (h: Hit) => h.effect === 'prohibe_circular';
  const pax = (h: Hit) => h.effect === 'prohibe_parrillero';
  const blocks = (h: Hit) => circ(h) || (pax(h) && inp.withPassenger === true);
  let canCirculate: boolean | null = true;
  if (!rules.length) canCirculate = null;
  else if (hits.some(h => live(h) && blocks(h))) canCirculate = false;
  else if (hits.some(h => pending(h) && blocks(h) && (inp.time === undefined || true))) canCirculate = null;
  const passengerAllowed = !rules.length ? null : hits.some(h => live(h) && pax(h)) ? false : hits.some(h => pending(h) && pax(h)) ? null : true;
  return { canCirculate, coverage: rules.length ? 'con_reglas' : 'sin_reglas', passengerAllowed, hits, date: inp.date, time: inp.time };
}

/** Semáforo. rojo = hay restricción que impide circular ese día (el detalle trae horarios); amarillo = restricciones
 *  parciales o por verificar (zona, parrillero, excepción pendiente, informativas); verde = ninguna; gris = sin reglas cargadas. */
export function buildCalendar(base: Omit<CheckInput, 'date' | 'time'>, rules: MobilityRule[], from: string, days: number) {
  return Array.from({ length: days }, (_, k) => {
    const result = checkRestrictionsCore({ ...base, date: addDays(from, k) }, rules);
    const rel = result.hits.filter(h => h.state !== 'exceptuada');
    const red = rel.some(h => h.state === 'aplica_dia' && (h.effect === 'prohibe_circular' || (h.effect === 'prohibe_parrillero' && base.withPassenger === true)));
    const color = result.coverage === 'sin_reglas' ? 'gris' : red ? 'rojo' : rel.length ? 'amarillo' : 'verde';
    return { date: result.date, color: color as 'verde'|'amarillo'|'rojo'|'gris', result };
  });
}
export interface RegionGeo { id: string; type: string; center?: { lat: number; lng: number }; radiusKm?: number }
/** Aproximado: región más pequeña cuyo círculo (centro+radio) contiene el punto. Sin coincidencia => null => selección manual. */
export function nearestRegion(p: { lat: number; lng: number }, regions: RegionGeo[]): string | null {
  const km = (a: typeof p, b: typeof p) => { const R = 6371, rad = (x: number) => x * Math.PI / 180;
    const h = Math.sin(rad(b.lat - a.lat) / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(rad(b.lng - a.lng) / 2) ** 2; return 2 * R * Math.asin(Math.sqrt(h)); };
  const c = regions.filter(r => r.center && r.radiusKm && km(p, r.center) <= r.radiusKm).sort((a, b) => a.radiusKm! - b.radiusKm!);
  return c[0]?.id ?? null;
}
export function validateForPublish(r: MobilityRule): string[] {
  const e: string[] = []; const hm = /^([01]\d|2[0-3]):[0-5]\d$/;
  if (!r.regionId || !r.name || !r.kind || !r.effect) e.push('Faltan región, nombre, tipo o efecto.');
  if (!(KINDS as readonly string[]).includes(r.kind) || !(EFFECTS as readonly string[]).includes(r.effect)) e.push('Tipo o efecto no válido.');
  if (r.vehicleTypes?.some(v => !(VEHICLE_TYPES as readonly string[]).includes(v))) e.push('Tipo de vehículo no válido.');
  if (r.exceptions?.some(x => !x.note)) e.push('Toda excepción necesita una nota.');
  if (!r.source?.name || !r.source.verifiedAt) e.push('Una regla publicada exige fuente oficial y fecha de verificación.');
  if (r.windows?.some(w => !hm.test(w.start) || !hm.test(w.end))) e.push('Horario inválido (use HH:mm).');
  const all = [...Object.values(r.digitsByDay ?? {}), ...Object.values(r.digitsByDate ?? {}), ...(r.digitsByParity ? [r.digitsByParity.even, r.digitsByParity.odd] : [])].flat();
  if (all.some(d => !Number.isInteger(d) || d < 0 || d > 9)) e.push('Los dígitos deben ser 0–9.');
  if (r.zone?.polygon && r.zone.polygon.length < 3) e.push('El polígono necesita al menos 3 puntos.');
  if (r.validFrom && r.validTo && r.validFrom > r.validTo) e.push('Fecha inicial posterior a la final.');
  return e;
}

// ---------- Rutas ----------
export type LatLng = [number, number];
export function distanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371, r = (x: number) => x * Math.PI / 180;
  const h = Math.sin(r(b.lat - a.lat) / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(r(b.lng - a.lng) / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(h));
}
/** Decodifica "encoded polyline" (algoritmo estándar de Google, precisión 1e5). */
export function decodePolyline(s: string): LatLng[] {
  const out: LatLng[] = []; let i = 0, lat = 0, lng = 0;
  const next = () => { let sh = 0, r = 0, b: number; do { b = s.charCodeAt(i++) - 63; r |= (b & 31) << sh; sh += 5; } while (b >= 32); return r & 1 ? ~(r >> 1) : r >> 1; };
  while (i < s.length) { lat += next(); lng += next(); out.push([lat / 1e5, lng / 1e5]); }
  return out;
}
function densify(path: LatLng[], stepM = 50): LatLng[] {
  const out: LatLng[] = [];
  for (let k = 0; k < path.length - 1; k++) {
    const [a, b] = [path[k], path[k + 1]]; const n = Math.max(1, Math.ceil(distanceKm({ lat: a[0], lng: a[1] }, { lat: b[0], lng: b[1] }) * 1000 / stepM));
    for (let j = 0; j < n; j++) out.push([a[0] + (b[0] - a[0]) * j / n, a[1] + (b[1] - a[1]) * j / n]);
  }
  if (path.length) out.push(path[path.length - 1]); return out;
}
export interface Crossing { ruleId: string; name: string; zoneName: string; polygon?: [number, number][]; state: HitState; schedule: Win[]; source?: MobilityRule['source'] }
export interface RouteAnalysis { crossings: Crossing[]; unverifiable: { ruleId: string; name: string; corridors: string[] }[]; blocking: boolean }
/** Cruza la ruta con zonas de reglas PUBLICADAS que aplican al vehículo. Solo afirma lo que puede comprobar geográficamente:
 *  reglas con corredores pero sin polígono se devuelven como "por verificar", nunca como cruce. */
export function analyzeRoute(path: LatLng[], base: Omit<CheckInput, 'location'>, rules: MobilityRule[]): RouteAnalysis {
  const pts = densify(path); const crossings: Crossing[] = []; const unverifiable: RouteAnalysis['unverifiable'] = [];
  for (const r of rules) {
    if (r.status !== 'publicada' || !r.zone) continue;
    const hit = checkRestrictionsCore(base, [{ ...r, zone: undefined }]).hits[0];   // ¿aplica al vehículo, día y hora?
    if (!hit || hit.state === 'exceptuada') continue;
    if (r.zone.polygon) {
      if (pts.some(p => inPolygon({ lat: p[0], lng: p[1] }, r.zone!.polygon!)))
        crossings.push({ ruleId: r.id, name: r.name, zoneName: r.zone.name, polygon: r.zone.polygon, state: hit.state, schedule: r.windows ?? [], source: r.source });
    } else unverifiable.push({ ruleId: r.id, name: r.name, corridors: r.zone.corridors ?? [r.zone.name] });
  }
  const live = (c: Crossing) => c.state === 'activa' || c.state === 'aplica_dia';
  const rule = (id: string) => rules.find(x => x.id === id)!;
  return { crossings, unverifiable, blocking: crossings.some(c => live(c) && (rule(c.ruleId).effect === 'prohibe_circular' || (rule(c.ruleId).effect === 'prohibe_parrillero' && base.withPassenger === true))) };
}
