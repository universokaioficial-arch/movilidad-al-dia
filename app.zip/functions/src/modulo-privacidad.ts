import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { guard } from './guard.js';
import { anonymizedAuthUpdate, anonymizedProfilePatch, deletionTransition, redactForExport } from './privacy-core.js';
const db = getFirestore();
const clean = (o: any) => JSON.parse(JSON.stringify(o, (_k, v) => (v && typeof v.toDate === 'function' ? v.toDate().toISOString() : v)));

/** Derecho de acceso: el usuario descarga TODOS sus datos (sin tokens de dispositivo). */
export const exportMyData = onCall(async req => {
  const uid = await guard(req, 'export', 5);
  const profile = (await db.doc(`users/${uid}`).get()).data() ?? {};
  const vehicles = await Promise.all((await db.collection(`users/${uid}/vehicles`).get()).docs.map(async v => ({ id: v.id, ...v.data(),
    documents: await Promise.all((await v.ref.collection('documents').get()).docs.map(async d => ({ id: d.id, ...d.data(), renewals: (await d.ref.collection('renewals').get()).docs.map(r => r.data()) }))) })));
  const reports = (await db.collection('reports').where('authorId', '==', uid).get()).docs.map(d => ({ id: d.id, ...d.data() }));
  const notifications = (await db.collection(`users/${uid}/notifications`).orderBy('createdAt', 'desc').limit(200).get()).docs.map(d => d.data());
  return clean({ exportedAt: new Date().toISOString(), profile: redactForExport(profile), vehicles, reports, notifications });
});

/** Solicitud de eliminación/anonimización. No borra nada automáticamente: la atiende un Super Administrador. */
export const requestAccountDeletion = onCall(async req => {
  const uid = req.auth?.uid; if (!uid) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  try { await db.doc(`deletion_requests/${uid}`).create({ uid, email: req.auth?.token?.email ?? null, status: 'pendiente', requestedAt: new Date().toISOString() }); }
  catch { throw new HttpsError('already-exists', 'Ya tienes una solicitud en curso.'); }
  return { ok: true, status: 'pendiente' };
});

export const resolveDeletionRequest = onCall(async req => {
  if ((req.auth?.token as any)?.role !== 'super_admin') throw new HttpsError('permission-denied', 'Solo el Super Administrador.');
  const { uid, to, note } = req.data ?? {}; const ref = db.doc(`deletion_requests/${uid}`); const s = await ref.get();
  if (!s.exists) throw new HttpsError('not-found', 'Solicitud no encontrada.'); if (!deletionTransition(s.data()!.status, to)) throw new HttpsError('failed-precondition', 'Transición no permitida.');
  if (to === 'completada') {               // anonimiza el perfil, archiva vehículos y deshabilita el acceso; el historial se conserva
    await db.doc(`users/${uid}`).set({ ...anonymizedProfilePatch(new Date().toISOString()), updatedBy: req.auth!.uid }, { merge: true });
    for (const v of (await db.collection(`users/${uid}/vehicles`).get()).docs) await v.ref.update({ archivedAt: new Date().toISOString(), updatedBy: req.auth!.uid });
    await getAuth().updateUser(uid, anonymizedAuthUpdate(uid));                                  // quita correo, nombre, foto y teléfono de Auth sin eliminar la cuenta
    await getAuth().updateUser(uid, { providersToUnlink: ['google.com'] }).catch(() => {});       // si no tenía Google, no pasa nada
    await getAuth().revokeRefreshTokens(uid); await db.doc(`deletion_requests/${uid}`).update({ email: null });
  }
  await ref.update({ status: to, note: String(note ?? '').slice(0, 500), resolvedBy: req.auth!.uid, resolvedAt: new Date().toISOString(), serverUpdatedAt: FieldValue.serverTimestamp() });
  return { ok: true };
});
