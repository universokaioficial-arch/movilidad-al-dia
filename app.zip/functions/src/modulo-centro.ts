import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { onDocumentWritten } from 'firebase-functions/v2/firestore';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getMessaging } from 'firebase-admin/messaging';
import { guard } from './guard.js';
import { audit } from './modulo-vehiculos.js';
import { nearestRegion, type RegionGeo } from './restrictions.js';
import { validateAlert, validateNews, validateReport, reportTransition, topicFor, type AlertIn, type NewsIn } from './centro-core.js';
const db = getFirestore();
const admin = (t: any) => ['super_admin', 'admin'].includes(t?.role);

async function saveContent(coll: 'alerts' | 'news', req: any, validate: (x: any, p: boolean) => string[]) {
  if (!admin(req.auth?.token)) throw new HttpsError('permission-denied', 'Solo administradores.');
  const x = req.data?.item; const publish = req.data?.publish === true;
  const status = publish ? 'publicada' : x?.status === 'archivada' ? 'archivada' : 'borrador';
  const errs = validate({ ...x, status }, publish); if (errs.length) throw new HttpsError('failed-precondition', errs.join(' '));
  if (x.regionId && !(await db.doc(`regions/${x.regionId}`).get()).exists) throw new HttpsError('failed-precondition', 'La región no existe.');
  const ref = db.doc(`${coll}/${x.id}`); const prev = (await ref.get()).data();
  await ref.set({ ...x, status, origin: 'oficial', updatedAt: new Date().toISOString(), updatedBy: req.auth.uid });
  if (coll === 'alerts' && publish && prev?.status !== 'publicada' && req.data?.notify !== false && x.severity !== 'info') {
    try { await getMessaging().send({ topic: topicFor(x.regionId, x.type), notification: { title: x.severity === 'critical' ? 'Alerta importante' : 'Movilidad al Día', body: x.title }, data: { alertId: x.id } }); }
    catch (e) { console.error('FCM topic', e); } // la alerta queda publicada aunque falle el push
  }
  return { ok: true, status };
}
export const saveAlert = onCall(req => saveContent('alerts', req, (x, p) => validateAlert(x as AlertIn, p)));
export const saveNews = onCall(req => saveContent('news', req, (x, p) => validateNews(x as NewsIn, p)));
export const onAlertAudit = onDocumentWritten('alerts/{id}', e => audit('alerta', e.document, e.data?.before.data(), e.data?.after.data()));
export const onNewsAudit = onDocumentWritten('news/{id}', e => audit('noticia', e.document, e.data?.before.data(), e.data?.after.data()));
export const onReportAudit = onDocumentWritten('reports/{id}', e => audit('reporte', e.document, e.data?.before.data(), e.data?.after.data()));

// Reporte ciudadano: siempre nace "pendiente"; hasta 10 por día por usuario.
export const createReport = onCall(async req => {
  const uid = await guard(req);
  const d = req.data ?? {}; const errs = validateReport(d, uid); if (errs.length) throw new HttpsError('invalid-argument', errs.join(' '));
  if (d.fromGps && (await db.doc(`users/${uid}`).get()).data()?.consents?.location !== true) throw new HttpsError('permission-denied', 'Falta consentimiento de ubicación.');
  const since = new Date(Date.now() - 864e5).toISOString();
  const n = (await db.collection('reports').where('authorId', '==', uid).where('createdAtIso', '>=', since).count().get()).data().count;
  if (n >= 10) throw new HttpsError('resource-exhausted', 'Límite diario de reportes alcanzado.');
  const regions = (await db.collection('regions').get()).docs.map(r => ({ id: r.id, ...r.data() }) as RegionGeo);
  const ref = await db.collection('reports').add({ authorId: uid, type: d.type, geo: { lat: d.lat, lng: d.lng }, description: String(d.description ?? '').trim(), photoPath: d.photoPath ?? null,
    regionId: nearestRegion({ lat: d.lat, lng: d.lng }, regions), status: 'pendiente', createdAtIso: new Date().toISOString(), createdAt: FieldValue.serverTimestamp(), history: [], updatedBy: uid });
  return { id: ref.id, status: 'pendiente' };
});

// Moderación: solo transiciones válidas. Al verificar se publica una copia PÚBLICA sin autor, foto ni texto libre.
export const moderateReport = onCall(async req => {
  if (!admin(req.auth?.token)) throw new HttpsError('permission-denied', 'Solo administradores.');
  const { id, to, publicText } = req.data ?? {}; const ref = db.doc(`reports/${id}`); const now = new Date().toISOString();
  const r = await db.runTransaction(async tx => {
    const s = await tx.get(ref); if (!s.exists) throw new HttpsError('not-found', 'Reporte no encontrado.');
    const x = s.data()!; if (!reportTransition(x.status, to)) throw new HttpsError('failed-precondition', `No se puede pasar de ${x.status} a ${to}.`);
    tx.update(ref, { status: to, updatedBy: req.auth!.uid, history: FieldValue.arrayUnion({ status: to, by: req.auth!.uid, at: now }) });
    const pub = db.doc(`public_reports/${id}`);
    if (to === 'verificado') tx.set(pub, { type: x.type, geo: x.geo, regionId: x.regionId ?? null, status: 'verificado', verifiedAt: now, publicText: publicText ? String(publicText).slice(0, 280) : null, label: 'Reporte ciudadano verificado; no es información oficial' });
    if (to === 'cerrado') tx.set(pub, { status: 'cerrado', closedAt: now }, { merge: true });
    return x;
  });
  const u = (await db.doc(`users/${r.authorId}`).get()).data();
  if (u?.notificationPrefs?.reportes !== false) await db.collection(`users/${r.authorId}/notifications`).add({ kind: 'reporte', level: 'info', body: `Tu reporte (${r.type}) cambió a: ${to.replace('_', ' ')}.`, createdAt: FieldValue.serverTimestamp(), readAt: null });
  return { ok: true };
});
