import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { defineSecret } from 'firebase-functions/params';
import { getFirestore } from 'firebase-admin/firestore';
import { todayBogota } from './domain.js';
import { regionChain } from './modulo-restricciones.js';
import { analyzeRoute, decodePolyline, distanceKm, nearestRegion, type MobilityRule, type RegionGeo, type VehicleType } from './restrictions.js';
import { guard } from './guard.js';
import { ALLOWED_TYPES, FALLBACK_MESSAGE, classifyGoogleStatus, fieldMask, isPhotoName, mapPlace, mergeAndRank, sanitizeQueries } from './directory-core.js';
import { CATEGORIES, validateDirectoryEntry, type DirectoryEntry } from './maps-core.js';

const MAPS_KEY = defineSecret('GOOGLE_MAPS_SERVER_KEY'); // firebase functions:secrets:set GOOGLE_MAPS_SERVER_KEY
const db = getFirestore();
const isAdmin = (t: any) => ['super_admin', 'admin'].includes(t?.role);

async function requireLocationConsent(uid: string) {
  if ((await db.doc(`users/${uid}`).get()).data()?.consents?.location !== true) throw new HttpsError('permission-denied', 'Falta consentimiento de ubicación.');
}
async function regionsGeo() { return (await db.collection('regions').get()).docs.map(x => ({ id: x.id, ...x.data() }) as RegionGeo & { name?: string; parentId?: string }); }

// Ciudad/departamento desde GPS (aproximado por centro+radio). Sin coincidencia => selección manual.
export const resolveRegion = onCall(async req => {
  const uid = await guard(req, 'region', 120);
  await requireLocationConsent(uid);
  const { lat, lng } = req.data ?? {}; if (typeof lat !== 'number' || typeof lng !== 'number') throw new HttpsError('invalid-argument', 'Coordenadas inválidas.');
  const all = await regionsGeo(); const id = nearestRegion({ lat, lng }, all);
  if (!id) return { needsManualRegion: true };
  const chain = await regionChain(id);
  return { regionId: id, chain: chain.map(c => ({ id: c, name: all.find(r => r.id === c)?.name ?? null, type: all.find(r => r.id === c)?.type ?? null })), approximate: true };
});

async function google(url: string, body: object | null, mask: string): Promise<any> {
  const key = MAPS_KEY.value(); if (!key) throw new HttpsError('unavailable', FALLBACK_MESSAGE, { reason: 'no_key' });      // sin credencial: se dice claramente, no se muestra nada falso
  let r: Response; try { r = await fetch(url, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': key, 'X-Goog-FieldMask': mask }, body: body ? JSON.stringify(body) : undefined }); }
  catch { throw new HttpsError('unavailable', FALLBACK_MESSAGE, { reason: 'network' }); }
  if (!r.ok) throw new HttpsError('unavailable', FALLBACK_MESSAGE, { reason: classifyGoogleStatus(r.status), status: r.status });
  return r.json();
}
const googlePlaces = async (body: object, detail: 'basic' | 'full'): Promise<any[]> => ((await google('https://places.googleapis.com/v1/places:searchText', { languageCode: 'es-CO', regionCode: 'CO', maxResultCount: 10, ...body }, fieldMask(detail))).places ?? []);

// Directorio: primero entradas verificadas por nosotros; luego lugares REALES de Google Places, ordenados por distancia. Nunca se rellena con datos inventados.
export const searchServices = onCall({ secrets: [MAPS_KEY] }, async req => {
  const uid = await guard(req, 'search', 60);
  const d = req.data ?? {}; const { category, query, lat, lng, regionId, fromGps } = d; const radiusM = Math.min(Math.max(Number(d.radiusM ?? 5000), 500), 50000);
  if (typeof lat !== 'number' || typeof lng !== 'number') throw new HttpsError('invalid-argument', 'Falta la ubicación (GPS o manual).');
  if (fromGps) await requireLocationConsent(uid);
  const cat = category ? CATEGORIES[category] : undefined; if (category && !cat) throw new HttpsError('invalid-argument', 'Categoría no válida.');
  const here = { lat, lng }; let curated: any[] = [];
  if (category && regionId) {
    const chain = await regionChain(regionId);
    const s = await db.collection('directory').where('status', '==', 'publicada').where('category', '==', category).where('regionId', 'in', chain).get();
    curated = s.docs.map(x => x.data() as DirectoryEntry).map(e => ({ ...e, origen: 'verificado', distanceKm: distanceKm(here, e) })).sort((a, b) => a.distanceKm - b.distanceKm);
  }
  const qs = sanitizeQueries(d.queries); const list = qs.length ? qs : [String(query ?? cat?.query ?? '').trim()].filter(Boolean);
  if (!list.length) throw new HttpsError('invalid-argument', 'Falta qué buscar.');
  const type = ALLOWED_TYPES.includes(d.includedType) ? d.includedType : undefined; const detail = d.detail === 'basic' ? 'basic' : 'full';
  const minRating = typeof d.minRating === 'number' && d.minRating >= 1 && d.minRating <= 5 ? Math.round(d.minRating * 2) / 2 : undefined;
  const raw = await Promise.all(list.map(q => googlePlaces({ textQuery: q, rankPreference: 'DISTANCE', locationBias: { circle: { center: { latitude: lat, longitude: lng }, radius: radiusM } },
    ...(type ? { includedType: type, strictTypeFiltering: true } : {}), ...(d.openNow === true ? { openNow: true } : {}), ...(minRating ? { minRating } : {}) }, detail)));
  const external = mergeAndRank(raw, here, { radiusKm: radiusM / 1000, openNow: d.openNow === true, minRating, limit: Math.min(Number(d.limit ?? 15), 20) });
  return { curated, external, fetchedAt: new Date().toISOString() };   // no se guardan resultados de Google (solo placeId en favoritos)
});

// Foto de un lugar: Google devuelve una dirección temporal sin clave (skipHttpRedirect), así la clave del servidor nunca llega al navegador.
export const placePhoto = onCall({ secrets: [MAPS_KEY] }, async req => {
  await guard(req, 'photo', 60); const name = req.data?.name; if (!isPhotoName(name)) throw new HttpsError('invalid-argument', 'Foto no válida.');
  const w = Math.min(Math.max(Number(req.data?.maxWidth ?? 480), 100), 800);
  const j = await google(`https://places.googleapis.com/v1/${name}/media?maxWidthPx=${w}&skipHttpRedirect=true`, null, 'name,photoUri');
  if (!j.photoUri) throw new HttpsError('not-found', 'Google no entregó la foto.'); return { uri: j.photoUri as string };
});

// Ubicación manual: buscar una ciudad, barrio o dirección real (sirve aunque no haya regiones cargadas en la base de datos).
export const findPlace = onCall({ secrets: [MAPS_KEY] }, async req => {
  await guard(req, 'findplace', 40); const q = String(req.data?.query ?? '').trim(); if (q.length < 3 || q.length > 100) throw new HttpsError('invalid-argument', 'Escribe al menos 3 letras.');
  const raw = await googlePlaces({ textQuery: q, maxResultCount: 5 }, 'basic'); return { places: raw.map(g => mapPlace(g, null)).filter(Boolean) };
});

// Ruta + restricciones del motor. Recomienda la alternativa sin cruces vigentes si el proveedor devolvió alguna.
export const routeWithRestrictions = onCall({ secrets: [MAPS_KEY] }, async req => {
  const uid = await guard(req, 'route', 30);
  const { origin, destination, originFromGps, plate, withPassenger, originRegionId } = req.data ?? {};
  const ok = (p: any) => p && typeof p.lat === 'number' && typeof p.lng === 'number';
  if (!ok(origin) || !ok(destination)) throw new HttpsError('invalid-argument', 'Origen y destino requeridos.');
  if (originFromGps) await requireLocationConsent(uid);
  const pt = (p: any) => ({ location: { latLng: { latitude: p.lat, longitude: p.lng } } });
  const r = await fetch('https://routes.googleapis.com/directions/v2:computeRoutes', { method: 'POST',
    headers: { 'Content-Type': 'application/json', 'X-Goog-Api-Key': MAPS_KEY.value(), 'X-Goog-FieldMask': 'routes.distanceMeters,routes.duration,routes.polyline.encodedPolyline,routes.description' },
    body: JSON.stringify({ origin: pt(origin), destination: pt(destination), travelMode: 'DRIVE', routingPreference: 'TRAFFIC_AWARE', computeAlternativeRoutes: true, languageCode: 'es-CO', units: 'METRIC' }) });
  if (!r.ok) throw new HttpsError('unavailable', `Google Routes respondió ${r.status}`);
  const routes: any[] = ((await r.json()) as any).routes ?? []; if (!routes.length) return { routes: [], message: 'El proveedor no devolvió rutas.' };

  const vref = plate ? db.doc(`users/${uid}/vehicles/${String(plate)}`) : (await db.collection(`users/${uid}/vehicles`).where('isMain', '==', true).limit(1).get()).docs[0]?.ref;
  const v = vref && (await vref.get()).data();
  const all = await regionsGeo();
  const ids = [originRegionId ?? nearestRegion(origin, all), nearestRegion(destination, all)].filter(Boolean) as string[];
  const chain = [...new Set((await Promise.all(ids.map(regionChain))).flat())];
  let rules: MobilityRule[] = [];
  if (chain.length) rules = (await db.collection('mobility_rules').where('status', '==', 'publicada').where('regionId', 'in', chain.slice(0, 30)).get()).docs.map(d => ({ ...d.data(), id: d.id }) as MobilityRule);
  const now = new Date(); const time = new Intl.DateTimeFormat('en-GB', { timeZone: 'America/Bogota', hour: '2-digit', minute: '2-digit', hour12: false }).format(now);
  const base = v && !v.archivedAt ? { date: todayBogota(now), time, regionChain: chain, withPassenger: withPassenger === true, vehicle: { plate: v.plate, type: v.type as VehicleType, fuel: v.fuel, cc: v.cc } } : null;

  const out = routes.map((rt, index) => {
    const analysis = base ? analyzeRoute(decodePolyline(rt.polyline.encodedPolyline), base, rules) : null;
    return { index, distanceM: rt.distanceMeters, durationS: parseInt(String(rt.duration ?? '0'), 10), summary: rt.description ?? null, polyline: rt.polyline.encodedPolyline, analysis,
      warning: analysis?.crossings.some(c => c.state === 'activa' || c.state === 'aplica_dia') ? '⚠️ Esta ruta atraviesa una zona con restricción.' : null };
  });
  const clean = out.find(o => o.analysis && !o.analysis.blocking && !o.warning);
  const coverageNote = !base ? 'Sin vehículo seleccionado: no se evaluaron restricciones.' : !rules.length ? 'No hay reglas publicadas para esta zona: no se pudo verificar restricciones.' : out.some(o => o.analysis?.unverifiable.length) ? 'Algunas restricciones (corredores sin polígono) no se pueden comprobar en el mapa.' : null;
  return { routes: out, recommendedIndex: clean?.index ?? 0, alternativeAvailable: !!clean && clean.index !== 0, coverageNote };
});

export const saveDirectoryEntry = onCall(async req => {
  if (!isAdmin(req.auth?.token)) throw new HttpsError('permission-denied', 'Solo administradores.');
  const e = req.data?.entry as DirectoryEntry; const publish = req.data?.publish === true;
  const errs = validateDirectoryEntry({ ...e, status: publish ? 'publicada' : e?.status === 'archivada' ? 'archivada' : 'borrador' }, publish);
  if (errs.length) throw new HttpsError('failed-precondition', errs.join(' '));
  await db.doc(`directory/${e.id}`).set({ ...e, status: publish ? 'publicada' : e.status === 'archivada' ? 'archivada' : 'borrador', updatedAt: new Date().toISOString(), updatedBy: req.auth!.uid });
  return { ok: true };
});
