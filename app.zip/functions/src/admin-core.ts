export const ROLES = ['super_admin', 'admin', 'conductor', 'runner', 'usuario'] as const;
export const REGION_TYPES = ['departamento', 'ciudad', 'municipio', 'distrito', 'zona_especial'] as const;
export interface RegionIn { id: string; name: string; type: string; parentId?: string; center?: { lat: number; lng: number }; radiusKm?: number }
export function validateRegion(r: RegionIn): string[] {
  const e: string[] = [];
  if (!/^[a-z0-9][a-z0-9-]{1,60}$/.test(r?.id ?? '')) e.push('El id debe ser un slug (minúsculas, números y guiones).');
  if (!r?.name?.trim()) e.push('Falta el nombre.');
  if (!(REGION_TYPES as readonly string[]).includes(r?.type)) e.push('Tipo de región no válido.');
  if (r?.type !== 'departamento' && !r?.parentId) e.push('Toda región que no es departamento necesita un padre.');
  if (r?.parentId === r?.id) e.push('Una región no puede ser su propio padre.');
  if (r?.center && !(r.center.lat >= -5 && r.center.lat <= 14 && r.center.lng >= -82 && r.center.lng <= -66)) e.push('El centro está fuera de Colombia.');
  if (r?.center && !(r.radiusKm! >= 0.5 && r.radiusKm! <= 500)) e.push('Con centro, el radio debe estar entre 0,5 y 500 km.');
  return e;
}
/** null = permitido. El conteo de super administradores restantes lo verifica la función con la base de datos. */
export function roleChangeError(actor: { uid: string; role?: string }, targetUid: string, newRole: string): string | null {
  if (actor.role !== 'super_admin') return 'Solo el Super Administrador cambia roles.';
  if (!(ROLES as readonly string[]).includes(newRole)) return 'Rol no válido.';
  if (actor.uid === targetUid) return 'No puedes cambiar tu propio rol.';
  return null;
}
