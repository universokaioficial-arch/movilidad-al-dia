// Motor de pico y placa: función pura, sin datos de ciudades incrustados.
// Las reglas vienen de Firestore (pico_placa_rules) y las edita el admin.
export type VehicleType = 'automovil'|'motocicleta'|'moto_electrica'|'ciclomotor'|'camioneta'|'camion'|'taxi'|'otro';
export type Status = 'puede_circular'|'restriccion_parcial'|'no_puede_circular';

export interface PicoPlacaRule {
  id: string; regionId: string; kind: 'pico_placa'|'regional'|'parrillero'|'temporal'|'evento'|'zona';
  vehicleTypes: VehicleType[];
  // día ISO (1=lun..7=dom) -> dígitos restringidos. Vacío = sin restricción ese día.
  digitsByDay: Record<number, number[]>;
  windows: { start: string; end: string }[];     // "HH:mm", hora de Colombia
  validFrom?: string; validTo?: string;          // YYYY-MM-DD (reglas temporales)
  exceptions?: { date?: string; plates?: string[]; note: string }[];
  active: boolean; source?: string; updatedAt: string;
}
export interface Answer { status: Status; rule?: PicoPlacaRule; windows: {start:string;end:string}[]; reason: string }

const toMin = (t: string) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };

export function lastDigit(plate: string): number | null {
  const m = plate.toUpperCase().replace(/[^A-Z0-9]/g, '').match(/(\d)[A-Z]?$/); // motos: ABC12D -> 2
  return m ? Number(m[1]) : null;
}

/** date: 'YYYY-MM-DD', isoDay 1..7, time 'HH:mm' (ya en America/Bogota). */
export function evaluate(rules: PicoPlacaRule[], plate: string, type: VehicleType,
                         date: string, isoDay: number, time: string): Answer {
  const d = lastDigit(plate);
  if (d === null) return { status: 'puede_circular', windows: [], reason: 'Placa inválida: no se pudo evaluar.' };
  let partial: Answer | null = null;
  for (const r of rules) {
    if (!r.active || !r.vehicleTypes.includes(type)) continue;
    if ((r.validFrom && date < r.validFrom) || (r.validTo && date > r.validTo)) continue;
    if (r.exceptions?.some(e => e.date === date || e.plates?.includes(plate.toUpperCase()))) continue;
    if (!(r.digitsByDay[isoDay] ?? []).includes(d)) continue;
    const now = toMin(time);
    const inside = r.windows.some(w => now >= toMin(w.start) && now < toMin(w.end));
    if (inside) return { status: 'no_puede_circular', rule: r, windows: r.windows, reason: 'Restricción vigente ahora.' };
    partial ??= { status: 'restriccion_parcial', rule: r, windows: r.windows, reason: 'Hay restricción hoy, fuera de su horario actual.' };
  }
  return partial ?? { status: 'puede_circular', windows: [], reason: 'Sin restricción según las reglas cargadas.' };
}
