import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { onDocumentWritten } from 'firebase-functions/v2/firestore';
import { getFirestore } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { audit } from './modulo-vehiculos.js';
import { validateRegion, roleChangeError, type RegionIn } from './admin-core.js';
const db = getFirestore();

export const saveRegion = onCall(async req => {
  if (!['super_admin', 'admin'].includes((req.auth?.token as any)?.role)) throw new HttpsError('permission-denied', 'Solo administradores.');
  const r = req.data?.region as RegionIn; const errs = validateRegion(r);
  if (!errs.length && r.parentId) { // el padre existe y no hay ciclos
    let cur: string | undefined = r.parentId;
    for (let i = 0; cur && i < 8; i++) { if (cur === r.id) errs.push('Ciclo en la jerarquía.'); const d = await db.doc(`regions/${cur}`).get(); if (!d.exists) { errs.push('La región padre no existe.'); break; } cur = d.data()?.parentId; }
  }
  if (errs.length) throw new HttpsError('failed-precondition', errs.join(' '));
  await db.doc(`regions/${r.id}`).set({ ...r, updatedAt: new Date().toISOString(), updatedBy: req.auth!.uid }); // nunca se borra: no existe endpoint de borrado
  return { ok: true };
});
export const onRegionAudit = onDocumentWritten('regions/{id}', e => audit('region', e.document, e.data?.before.data(), e.data?.after.data()));

export const setUserRole = onCall(async req => {
  const actor = { uid: req.auth?.uid ?? '', role: (req.auth?.token as any)?.role as string | undefined };
  if (!actor.uid) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  const { uid, email, role } = req.data ?? {};
  const target = uid ? await getAuth().getUser(String(uid)) : await getAuth().getUserByEmail(String(email)).catch(() => null);
  if (!target) throw new HttpsError('not-found', 'Usuario no encontrado.');
  const err = roleChangeError(actor, target.uid, String(role)); if (err) throw new HttpsError('permission-denied', err);
  if (target.customClaims?.role === 'super_admin' && role !== 'super_admin') {
    const n = (await db.collection('users').where('role', '==', 'super_admin').count().get()).data().count;
    if (n <= 1) throw new HttpsError('failed-precondition', 'No se puede quitar al último Super Administrador.');
  }
  await getAuth().setCustomUserClaims(target.uid, { ...target.customClaims, role });
  await db.doc(`users/${target.uid}`).set({ role, updatedBy: actor.uid }, { merge: true });
  await getAuth().revokeRefreshTokens(target.uid); // el usuario recibe su nuevo rol al volver a iniciar sesión
  return { ok: true };
});
