import { defineBoolean } from 'firebase-functions/params';
import { HttpsError, type CallableRequest } from 'firebase-functions/v2/https';
import { getFirestore } from 'firebase-admin/firestore';
import { expireAt, overLimit, rateDocId } from './rate-core.js';
const ENFORCE = defineBoolean('ENFORCE_APP_CHECK', { default: false });   // activar solo cuando App Check esté configurado en la consola y en la app
/** Sesión obligatoria + App Check (si está exigido) + tope por hora por usuario para operaciones que cuestan dinero. */
export async function guard(req: CallableRequest<any>, kind?: string, perHour = 60): Promise<string> {
  const uid = req.auth?.uid; if (!uid) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  if (ENFORCE.value() && !req.app) throw new HttpsError('failed-precondition', 'App Check requerido.');
  if (kind) {
    const db = getFirestore(); const ref = db.doc(`rate_limits/${rateDocId(uid, kind)}`);
    await db.runTransaction(async tx => { const n = (await tx.get(ref)).data()?.count ?? 0; if (overLimit(n, perHour)) throw new HttpsError('resource-exhausted', 'Demasiadas consultas. Intenta de nuevo en un rato.'); tx.set(ref, { count: n + 1, expireAt: expireAt() }); });
  }
  return uid;
}
