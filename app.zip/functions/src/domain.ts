// Lógica pura y verificable. Sin dependencias.
export const VEHICLE_TYPES = ['automovil','motocicleta','moto_electrica','ciclomotor','camioneta','camion','bus','taxi','vehiculo_especial','otro'] as const;
export const DOC_TYPES = ['soat','rtm','licencia_conduccion','tarjeta_propiedad','seguro_voluntario','otro'] as const;
export const THRESHOLDS = [0, 1, 3, 7, 15, 30, 60] as const;
export type DocStatus = 'vigente' | 'proximo_a_vencer' | 'vencido' | 'pendiente_informacion';

export function normalizePlate(p: string): string { return p.toUpperCase().replace(/[^A-Z0-9]/g, ''); }
// Carros ABC123, motos ABC12D, remolques R12345. Se acepta 5–7 alfanuméricos y se avisa si no coincide con un patrón conocido.
export function isPlausiblePlate(p: string): boolean { return /^[A-Z]{3}\d{3}$|^[A-Z]{3}\d{2}[A-Z]$|^[A-Z]\d{5}$|^[A-Z0-9]{5,7}$/.test(normalizePlate(p)); }

export function todayBogota(now = new Date()): string {
  return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Bogota' }).format(now); // YYYY-MM-DD
}
export function daysUntil(expiry: string, today: string): number {
  return Math.round((Date.parse(expiry + 'T00:00:00Z') - Date.parse(today + 'T00:00:00Z')) / 864e5);
}
export interface DocLike { type: string; expiryDate?: string | null; number?: string | null; filePath?: string | null; requiresExpiry?: boolean }

export function requiresExpiry(d: DocLike): boolean {
  if (d.type === 'tarjeta_propiedad') return false;
  if (d.type === 'otro') return d.requiresExpiry === true;
  return true;
}
export function documentStatus(d: DocLike, today: string): DocStatus {
  if (!requiresExpiry(d)) return d.number || d.filePath ? 'vigente' : 'pendiente_informacion';
  if (!d.expiryDate) return 'pendiente_informacion';
  const n = daysUntil(d.expiryDate, today);
  return n < 0 ? 'vencido' : n <= 60 ? 'proximo_a_vencer' : 'vigente';
}
export interface DueAlert { key: string; level: 'info' | 'warning' | 'critical'; days: number }
/** Alerta que corresponde HOY según la fecha real registrada. Usa el umbral más cercano cruzado,
 *  así un día sin ejecución del scheduler no pierde la alerta. Vencido: crítica al día siguiente y cada 7 días. */
export function dueAlert(d: DocLike, today: string): DueAlert | null {
  if (!requiresExpiry(d) || !d.expiryDate) return null;
  const n = daysUntil(d.expiryDate, today);
  if (n < 0) return { key: `${d.expiryDate}:vencido-${Math.floor((-n - 1) / 7)}`, level: 'critical', days: n };
  const t = THRESHOLDS.find(x => x >= n);
  if (t === undefined) return null;
  return { key: `${d.expiryDate}:d${t}`, level: t <= 7 ? 'warning' : 'info', days: n };
}
export function alertText(type: string, plate: string, a: DueAlert): string {
  const doc = ({ soat: 'SOAT', rtm: 'Revisión técnico-mecánica', licencia_conduccion: 'Licencia de conducción', tarjeta_propiedad: 'Tarjeta de propiedad', seguro_voluntario: 'Seguro voluntario' } as Record<string,string>)[type] ?? 'Documento';
  if (a.days < 0) return `${doc} del vehículo ${plate} está vencido desde hace ${-a.days} día(s).`;
  if (a.days === 0) return `${doc} del vehículo ${plate} vence hoy.`;
  return `${doc} del vehículo ${plate} vence en ${a.days} día(s).`;
}
