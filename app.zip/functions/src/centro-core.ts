// Centro de Movilidad: reglas puras. Sin dependencias.
export const ALERT_TYPES = ['accidente', 'cierre', 'obra', 'desvio', 'evento', 'estado_via', 'clima', 'importante'] as const;
export const REPORT_TYPES = ['accidente', 'hueco', 'calle_cerrada', 'semaforo_danado', 'obra', 'inundacion', 'vehiculo_varado', 'trancon', 'peligro'] as const;
export const REPORT_STATUS = ['pendiente', 'en_revision', 'verificado', 'rechazado', 'cerrado'] as const;
export type ReportStatus = typeof REPORT_STATUS[number];
const NEXT: Record<ReportStatus, ReportStatus[]> = { pendiente: ['en_revision', 'rechazado'], en_revision: ['verificado', 'rechazado', 'pendiente'], verificado: ['cerrado'], rechazado: [], cerrado: [] };
export const reportTransition = (from: string, to: string) => (NEXT as Record<string, string[]>)[from]?.includes(to) ?? false;
const inCO = (lat: number, lng: number) => lat >= -5 && lat <= 14 && lng >= -82 && lng <= -66;
const slug = /^[a-z0-9][a-z0-9-]{1,80}$/; const isDate = (s?: string) => !!s && /^\d{4}-\d{2}-\d{2}/.test(s);
export interface Source { name: string; url?: string; updatedAt?: string }  // updatedAt = fecha de actualización en la fuente
export interface AlertIn { id: string; type: string; title: string; description?: string; regionId: string; severity: string; geo?: { lat: number; lng: number }; validFrom?: string; validTo?: string; source?: Source; status: string }
export interface NewsIn { id: string; title: string; summary: string; regionId?: string; source?: Source; status: string }

export function validateAlert(a: AlertIn, publish: boolean): string[] {
  const e: string[] = [];
  if (!slug.test(a?.id ?? '')) e.push('Id inválido (slug).');
  if (!(ALERT_TYPES as readonly string[]).includes(a?.type)) e.push('Tipo de alerta no válido.');
  if (!a?.title?.trim()) e.push('Falta el título.'); if (!a?.regionId) e.push('Falta la región.');
  if (!['info', 'warning', 'critical'].includes(a?.severity)) e.push('Severidad no válida.');
  if (a?.geo && !inCO(a.geo.lat, a.geo.lng)) e.push('Ubicación fuera de Colombia.');
  if (a?.validFrom && a?.validTo && a.validFrom > a.validTo) e.push('Fecha inicial posterior a la final.');
  if (publish && (!a.source?.name || !isDate(a.source.updatedAt))) e.push('Publicar exige fuente y fecha de actualización de la fuente.');
  if (a?.source?.url && !/^https:\/\//.test(a.source.url)) e.push('La URL de la fuente debe ser https.');
  return e;
}
export function validateNews(n: NewsIn, publish: boolean): string[] {
  const e: string[] = [];
  if (!slug.test(n?.id ?? '')) e.push('Id inválido (slug).'); if (!n?.title?.trim() || !n?.summary?.trim()) e.push('Faltan título o resumen.');
  if (publish && (!n.source?.name || !isDate(n.source.updatedAt))) e.push('Publicar exige fuente y fecha.');
  if (n?.source?.url && !/^https:\/\//.test(n.source.url)) e.push('La URL de la fuente debe ser https.');
  return e;
}
export function validateReport(r: { type: string; lat: number; lng: number; description?: string; photoPath?: string }, uid: string): string[] {
  const e: string[] = [];
  if (!(REPORT_TYPES as readonly string[]).includes(r?.type)) e.push('Tipo de reporte no válido.');
  if (typeof r?.lat !== 'number' || typeof r?.lng !== 'number' || !inCO(r.lat, r.lng)) e.push('Ubicación inválida o fuera de Colombia.');
  if ((r?.description ?? '').length > 1000) e.push('La descripción supera 1000 caracteres.');
  if (r?.photoPath && !r.photoPath.startsWith(`reports/${uid}/`)) e.push('La foto debe estar en tu carpeta.');
  return e;
}
export const isActiveAlert = (a: { status: string; validFrom?: string; validTo?: string }, today: string) =>
  a.status === 'publicada' && (!a.validFrom || today >= a.validFrom) && (!a.validTo || today <= a.validTo);
export const topicFor = (regionId: string, type: string) => `${regionId}_${type}`.replace(/[^a-zA-Z0-9-_.~%]/g, '_');
