// Directorio: categorías y validación. Sin dependencias.
export const CATEGORIES: Record<string, { label: string; query: string; googleType?: string }> = {
  cda: { label: 'CDA', query: 'Centro de Diagnóstico Automotor CDA' },
  taller: { label: 'Talleres', query: 'taller mecánico', googleType: 'car_repair' },
  gasolinera: { label: 'Gasolineras', query: 'estación de servicio gasolinera', googleType: 'gas_station' },
  parqueadero: { label: 'Parqueaderos', query: 'parqueadero', googleType: 'parking' },
  lavadero: { label: 'Lavaderos', query: 'lavadero de carros', googleType: 'car_wash' },
  montallantas: { label: 'Montallantas', query: 'montallantas vulcanizadora' },
  centro_diagnostico: { label: 'Centros de diagnóstico', query: 'centro de diagnóstico automotriz' },
  concesionario: { label: 'Concesionarios', query: 'concesionario de vehículos', googleType: 'car_dealer' },
  grua: { label: 'Grúas', query: 'servicio de grúa' },
  ambulancia: { label: 'Ambulancias', query: 'servicio de ambulancia' },
  hospital: { label: 'Hospitales', query: 'hospital urgencias', googleType: 'hospital' },
  policia_transito: { label: 'Policía de tránsito', query: 'policía de tránsito y transporte' },
  secretaria_movilidad: { label: 'Secretarías de movilidad', query: 'secretaría de movilidad tránsito' },
  organismo_transito: { label: 'Organismos de tránsito', query: 'organismo de tránsito' }, // asumido: el mensaje del usuario quedó cortado en "Organismos de"
  otros: { label: 'Otros servicios relacionados', query: 'servicios para vehículos' },
  farmacia: { label: 'Farmacias', query: 'farmacia', googleType: 'pharmacy' },
  centro_medico: { label: 'Centros médicos', query: 'centro médico', googleType: 'hospital' },
};
export interface DirectoryEntry { id: string; category: string; name: string; regionId: string; lat: number; lng: number; address?: string; phone?: string;
  status: 'borrador' | 'publicada' | 'archivada'; source?: { name: string; url?: string; verifiedAt?: string }; updatedAt?: string }
export function validateDirectoryEntry(e: DirectoryEntry, publish: boolean): string[] {
  const err: string[] = [];
  if (!e.id || !e.name?.trim()) err.push('Falta id o nombre.');
  if (!CATEGORIES[e.category]) err.push('Categoría no válida.');
  if (!e.regionId) err.push('Falta la región.');
  if (!(e.lat >= -5 && e.lat <= 14 && e.lng >= -82 && e.lng <= -66)) err.push('Coordenadas fuera de Colombia.');
  if (e.phone && !/^[0-9+() \-]{6,20}$/.test(e.phone)) err.push('Teléfono con formato inválido.');
  if (publish && (!e.source?.name || !e.source.verifiedAt)) err.push('Publicar exige fuente y fecha de verificación.');
  return err;
}
