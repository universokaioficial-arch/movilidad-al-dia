export const hourKey = (d = new Date()) => d.toISOString().slice(0, 13).replace(/[-T:]/g, '');   // AAAAMMDDHH (UTC)
export const rateDocId = (uid: string, kind: string, d = new Date()) => `${uid}_${kind}_${hourKey(d)}`;
export const overLimit = (count: number, limit: number) => count >= limit;
export const expireAt = (d = new Date()) => new Date(d.getTime() + 2 * 3600e3);                // para la política TTL de Firestore
