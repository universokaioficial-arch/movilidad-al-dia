// Notificaciones: lógica pura. Sin dependencias.
export const CATEGORIES = ['pico_placa', 'parrillero', 'documentos', 'accidentes', 'cierres', 'noticias', 'clima', 'cambios'] as const;
export type Cat = typeof CATEGORIES[number];
export interface Prefs { push?: boolean; documents?: boolean; categories?: Partial<Record<Cat, boolean>> }
export const ALERT_CATEGORY: Record<string, Cat> = { accidente: 'accidentes', cierre: 'cierres', desvio: 'cierres', obra: 'cierres', estado_via: 'cierres', evento: 'cierres', clima: 'clima', importante: 'cambios' };
/** Categoría activada por el usuario (por defecto sí). Compatible con la preferencia anterior `documents`. */
export function categoryEnabled(p: Prefs | undefined, c: Cat): boolean {
  if (c === 'documentos' && p?.documents === false) return false; const v = p?.categories?.[c]; return v === undefined ? true : v;
}
export const topicName = (regionId: string, type: string) => `${regionId}_${type}`.replace(/[^a-zA-Z0-9-_.~%]/g, '_');
/** Temas FCM a los que debe estar suscrito: un tema por región y tipo de alerta cuya categoría esté activa. */
export function topicsFor(regionIds: string[], p: Prefs | undefined): string[] {
  if (p?.push === false) return []; const out = new Set<string>();
  for (const r of regionIds) {
    for (const [type, cat] of Object.entries(ALERT_CATEGORY)) if (categoryEnabled(p, cat)) out.add(topicName(r, type));
    if (categoryEnabled(p, 'noticias')) out.add(topicName(r, 'noticias'));
  }
  return [...out].sort();
}
export const diffTopics = (current: string[], desired: string[]) => ({ subscribe: desired.filter(t => !current.includes(t)), unsubscribe: current.filter(t => !desired.includes(t)) });
const fmt12 = (t: string) => { const [h, m] = t.split(':').map(Number); return `${h % 12 === 0 ? 12 : h % 12}:${String(m).padStart(2, '0')} ${h < 12 ? 'a. m.' : 'p. m.'}`; };
export interface HitLike { name: string; effect: string; state: string; schedule: { start: string; end: string }[]; zone?: { name: string } }
export interface DailyMsg { category: Cat; key: string; title: string; body: string }
/** Mensajes del día a partir del resultado del motor (evaluación de día completo). No inventa nada: sin restricción aplicable no hay mensaje. */
export function dailyMessages(hits: HitLike[], plate: string, date: string, p: Prefs | undefined): DailyMsg[] {
  const out: DailyMsg[] = []; const when = (h: HitLike) => h.schedule.length ? h.schedule.map(w => `${fmt12(w.start)} – ${fmt12(w.end)}`).join(' · ') : 'todo el día';
  const live = hits.filter(h => h.state === 'aplica_dia');
  const pico = live.find(h => h.effect === 'prohibe_circular'); const par = live.find(h => h.effect === 'prohibe_parrillero');
  if (pico && categoryEnabled(p, 'pico_placa')) out.push({ category: 'pico_placa', key: `pico-${date}`, title: 'Hoy tienes restricción', body: `${plate}: ${pico.name}${pico.zone ? ` en ${pico.zone.name}` : ''}. Horario: ${when(pico)}.` });
  if (par && categoryEnabled(p, 'parrillero')) out.push({ category: 'parrillero', key: `parrillero-${date}`, title: 'Restricción de parrillero hoy', body: `${par.name}: ${when(par)}.` });
  return out;
}
