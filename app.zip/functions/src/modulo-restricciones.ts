import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { onDocumentWritten } from 'firebase-functions/v2/firestore';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { todayBogota } from './domain.js';
import { audit } from './modulo-vehiculos.js';
import { buildCalendar, checkRestrictionsCore, nearestRegion, validateForPublish, addDays, type CheckInput, type MobilityRule, type RegionGeo, type VehicleType } from './restrictions.js';

const db = getFirestore();
const isAdmin = (t: any) => ['super_admin', 'admin'].includes(t?.role);

export async function regionChain(id: string): Promise<string[]> {
  const chain: string[] = []; let cur: string | undefined = id;
  for (let i = 0; cur && i < 6; i++) { chain.push(cur); cur = (await db.doc(`regions/${cur}`).get()).data()?.parentId; }
  return chain;
}
/** Función central. Lee reglas PUBLICADAS de Firestore y decide con el motor puro. */
export async function checkMobilityRestrictions(inp: Omit<CheckInput, 'regionChain'> & { regionId: string }) {
  const regionChain_ = await regionChain(inp.regionId);
  const snap = await db.collection('mobility_rules').where('status', '==', 'publicada').where('regionId', 'in', regionChain_).get();
  const rules = snap.docs.map(d => ({ ...d.data(), id: d.id }) as MobilityRule);
  return { rules, result: checkRestrictionsCore({ ...inp, regionChain: regionChain_ }, rules), regionChain: regionChain_ };
}

export const checkMobility = onCall(async req => {
  const uid = req.auth?.uid; if (!uid) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  const d = req.data ?? {}; const userRef = db.doc(`users/${uid}`);
  let regionId: string | null = d.regionId ?? null; let location: CheckInput['location'];
  if (d.lat != null && d.lng != null) { // la ubicación solo se usa con consentimiento registrado
    if ((await userRef.get()).data()?.consents?.location !== true) throw new HttpsError('permission-denied', 'Falta consentimiento de ubicación.');
    location = { lat: Number(d.lat), lng: Number(d.lng) };
    if (!regionId) { const rs = (await db.collection('regions').get()).docs.map(x => ({ id: x.id, ...x.data() }) as RegionGeo); regionId = nearestRegion(location, rs); }
  }
  if (!regionId) return { needsManualRegion: true }; // nunca se asume la ciudad de registro
  const vref = d.plate ? db.doc(`users/${uid}/vehicles/${String(d.plate)}`) : (await db.collection(`users/${uid}/vehicles`).where('isMain', '==', true).limit(1).get()).docs[0]?.ref;
  const v = vref && (await vref.get()).data(); if (!v || v.archivedAt) throw new HttpsError('not-found', 'No hay vehículo seleccionado.');
  const now = new Date(); const date = todayBogota(now);
  const time = new Intl.DateTimeFormat('en-GB', { timeZone: 'America/Bogota', hour: '2-digit', minute: '2-digit', hour12: false }).format(now);
  const base = { regionId, location, withPassenger: d.withPassenger, vehicle: { plate: v.plate, type: v.type as VehicleType, fuel: v.fuel, cc: v.cc } };
  const { rules, result, regionChain: chain } = await checkMobilityRestrictions({ ...base, date, time });
  const { regionId: _r, ...rest } = base;
  return { regionId, vehicle: { plate: v.plate, type: v.type }, now: result, calendar: buildCalendar({ ...rest, regionChain: chain }, rules, date, Math.min(Number(d.days ?? 14), 62)), tomorrow: addDays(date, 1) };
});

// Único camino para crear/editar/publicar reglas: valida y registra quién y cuándo.
export const saveMobilityRule = onCall(async req => {
  if (!isAdmin(req.auth?.token)) throw new HttpsError('permission-denied', 'Solo administradores.');
  const r = req.data?.rule as MobilityRule; const publish = req.data?.publish === true;
  if (!r?.id) throw new HttpsError('invalid-argument', 'Falta id.');
  const status = publish ? 'publicada' : (['archivada', 'derogada'].includes(r.status) ? r.status : 'borrador');
  const errors = publish ? validateForPublish({ ...r, status }) : [];
  if (errors.length) throw new HttpsError('failed-precondition', errors.join(' '));
  if (publish && !(await db.doc(`regions/${r.regionId}`).get()).exists) throw new HttpsError('failed-precondition', 'La región no existe.');
  await db.doc(`mobility_rules/${r.id}`).set({ ...r, status, updatedAt: new Date().toISOString(), updatedBy: req.auth!.uid, serverUpdatedAt: FieldValue.serverTimestamp() });
  return { ok: true, status };
});
export const onRuleAudit = onDocumentWritten('mobility_rules/{id}', e => audit('regla_movilidad', e.document, e.data?.before.data(), e.data?.after.data()));
