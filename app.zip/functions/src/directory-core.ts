// Directorio con Google Places (API nueva): máscara de campos, conversión, filtros y orden. Puro y sin dependencias.
export const FIELDS_BASIC = ['places.id', 'places.displayName', 'places.formattedAddress', 'places.location', 'places.googleMapsUri', 'places.businessStatus'];
// Los campos de teléfono, calificación, horarios y fotos son de una categoría de precio superior en Google: solo se piden en detalle "full".
export const FIELDS_FULL = [...FIELDS_BASIC, 'places.nationalPhoneNumber', 'places.internationalPhoneNumber', 'places.rating', 'places.userRatingCount', 'places.currentOpeningHours', 'places.photos'];
export const fieldMask = (detail: 'basic' | 'full') => (detail === 'basic' ? FIELDS_BASIC : FIELDS_FULL).join(',');
export const ALLOWED_TYPES = ['gas_station', 'car_repair', 'car_wash', 'parking', 'car_dealer', 'hospital', 'pharmacy', 'police'];
export interface GPlace { id?: string; displayName?: { text?: string }; formattedAddress?: string; location?: { latitude: number; longitude: number }; googleMapsUri?: string; businessStatus?: string;
  nationalPhoneNumber?: string; internationalPhoneNumber?: string; rating?: number; userRatingCount?: number; currentOpeningHours?: { openNow?: boolean; weekdayDescriptions?: string[] };
  photos?: { name?: string; authorAttributions?: { displayName?: string }[] }[] }
export interface PlaceOut { placeId: string; name: string; address: string | null; phone: string | null; lat: number; lng: number; mapsUri: string | null; rating: number | null; ratingCount: number | null;
  openNow: boolean | null; hoursText: string[] | null; photoName: string | null; photoAttribution: string | null; distanceKm: number | null; origen: 'google_maps'; aviso: string }
export function distanceKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const r = (x: number) => x * Math.PI / 180, h = Math.sin(r(b.lat - a.lat) / 2) ** 2 + Math.cos(r(a.lat)) * Math.cos(r(b.lat)) * Math.sin(r(b.lng - a.lng) / 2) ** 2; return 2 * 6371 * Math.asin(Math.sqrt(h));
}
/** Un lugar de Google → nuestro formato. Cada dato sale tal cual lo entrega Google; si falta, queda en null (nunca se inventa). Descarta lugares cerrados. */
export function mapPlace(g: GPlace, origin: { lat: number; lng: number } | null): PlaceOut | null {
  if (!g.id || !g.displayName?.text || !g.location) return null; if (g.businessStatus && g.businessStatus !== 'OPERATIONAL') return null;
  const p = { lat: g.location.latitude, lng: g.location.longitude }; const ph = g.photos?.[0];
  return { placeId: g.id, name: g.displayName.text, address: g.formattedAddress ?? null, phone: g.nationalPhoneNumber ?? g.internationalPhoneNumber ?? null, lat: p.lat, lng: p.lng, mapsUri: g.googleMapsUri ?? null,
    rating: typeof g.rating === 'number' ? g.rating : null, ratingCount: typeof g.userRatingCount === 'number' ? g.userRatingCount : null, openNow: typeof g.currentOpeningHours?.openNow === 'boolean' ? g.currentOpeningHours.openNow : null,
    hoursText: g.currentOpeningHours?.weekdayDescriptions?.length ? g.currentOpeningHours.weekdayDescriptions : null, photoName: ph?.name ?? null, photoAttribution: ph?.authorAttributions?.[0]?.displayName ?? null,
    distanceKm: origin ? Math.round(distanceKm(origin, p) * 100) / 100 : null, origen: 'google_maps', aviso: 'Dato de Google Maps; no verificado por Movilidad al Día.' };
}
export interface RankOpts { radiusKm?: number; openNow?: boolean; minRating?: number; limit?: number }
/** Une varias búsquedas, quita repetidos, filtra y ordena por distancia. Si no hay resultados devuelve lista vacía (no rellena). */
export function mergeAndRank(lists: GPlace[][], origin: { lat: number; lng: number }, o: RankOpts = {}): PlaceOut[] {
  const seen = new Set<string>(); const out: PlaceOut[] = [];
  for (const g of lists.flat()) { const p = mapPlace(g, origin); if (!p || seen.has(p.placeId)) continue; seen.add(p.placeId);
    if (o.radiusKm !== undefined && (p.distanceKm ?? Infinity) > o.radiusKm) continue; if (o.openNow && p.openNow !== true) continue; if (o.minRating !== undefined && !((p.rating ?? 0) >= o.minRating)) continue; out.push(p); }
  out.sort((a, b) => (a.distanceKm ?? Infinity) - (b.distanceKm ?? Infinity)); return o.limit ? out.slice(0, o.limit) : out;
}
export function sanitizeQueries(q: unknown): string[] { return Array.isArray(q) ? [...new Set(q.filter((x): x is string => typeof x === 'string').map(x => x.trim()).filter(x => x.length >= 2 && x.length <= 80))].slice(0, 3) : []; }
export type GoogleReason = 'no_key' | 'denied' | 'quota' | 'upstream' | 'network';
export const classifyGoogleStatus = (status: number): GoogleReason => (status === 401 || status === 403 ? 'denied' : status === 429 ? 'quota' : 'upstream');
export const FALLBACK_MESSAGE = 'El directorio de lugares reales requiere conexión con Google Maps.';
export const isPhotoName = (n: unknown): n is string => typeof n === 'string' && /^places\/[A-Za-z0-9_-]+\/photos\/[A-Za-z0-9_-]+$/.test(n);
