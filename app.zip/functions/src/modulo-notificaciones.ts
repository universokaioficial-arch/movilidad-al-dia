import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getMessaging } from 'firebase-admin/messaging';
import { todayBogota } from './domain.js';
import { checkRestrictionsCore, type MobilityRule, type VehicleType } from './restrictions.js';
import { regionChain } from './modulo-restricciones.js';
import { categoryEnabled, dailyMessages, diffTopics, topicsFor, type Prefs } from './notif-core.js';
const db = getFirestore();

async function tokensOf(uid: string) { const s = await db.collection(`users/${uid}/devices`).get(); return s.docs.map(d => ({ id: d.id, token: d.data().token as string })).filter(t => t.token); }
async function dropBad(uid: string, tokens: { id: string; token: string }[], res: { responses: { success: boolean; error?: { code?: string } }[] }) {
  await Promise.all(res.responses.map((r, i) => !r.success && /not-registered|invalid-registration/.test(r.error?.code ?? '') ? db.doc(`users/${uid}/devices/${tokens[i].id}`).delete() : null));
}
/** Sincroniza los temas FCM del usuario con sus preferencias y las ciudades que eligió para recibir avisos. */
export const syncTopics = onCall(async req => {
  const uid = req.auth?.uid; if (!uid) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  const u = (await db.doc(`users/${uid}`).get()).data() ?? {}; const prefs = u.notificationPrefs as Prefs | undefined;
  const regions: string[] = Array.isArray(u.notificationRegions) ? u.notificationRegions.filter((x: unknown) => typeof x === 'string').slice(0, 5) : [];
  const valid: string[] = []; for (const r of regions) if ((await db.doc(`regions/${r}`).get()).exists) valid.push(r);
  const subRef = db.doc(`notify_subscriptions/${uid}`); const cur: string[] = (await subRef.get()).data()?.topics ?? [];
  const desired = topicsFor(valid, prefs); const { subscribe, unsubscribe } = diffTopics(cur, desired);
  const tokens = await tokensOf(uid); const list = tokens.map(t => t.token);
  if (list.length) {
    for (const t of desired) await getMessaging().subscribeToTopic(list, t);        // idempotente: también cubre dispositivos nuevos
    for (const t of unsubscribe) await getMessaging().unsubscribeFromTopic(list, t);
  }
  const daily = (['pico_placa', 'parrillero'] as const).filter(c => categoryEnabled(prefs, c));
  await subRef.set({ topics: desired, regionIds: valid, daily: prefs?.push === false ? [] : daily, updatedAt: new Date().toISOString() });
  return { topics: desired.length, subscribed: subscribe.length, unsubscribed: unsubscribe.length, devices: list.length };
});

// Aviso diario de pico y placa / parrillero para quienes lo activaron, con su vehículo principal y la ciudad que eligieron.
export const dailyRestrictionNotices = onSchedule({ schedule: 'every day 06:00', timeZone: 'America/Bogota' }, async () => {
  const date = todayBogota(); const cache = new Map<string, MobilityRule[]>();
  const subs = await db.collection('notify_subscriptions').get();
  for (const s of subs.docs) {
    const x = s.data(); if (!x.daily?.length || !x.regionIds?.length) continue; const uid = s.id;
    const v = (await db.collection(`users/${uid}/vehicles`).where('isMain', '==', true).get()).docs.map(d => d.data()).find(d => !d.archivedAt); if (!v) continue;
    const chain = [...new Set((await Promise.all((x.regionIds as string[]).map(regionChain))).flat())]; const key = chain.join('|');
    if (!cache.has(key)) cache.set(key, (await db.collection('mobility_rules').where('status', '==', 'publicada').where('regionId', 'in', chain.slice(0, 30)).get()).docs.map(d => ({ ...d.data(), id: d.id }) as MobilityRule));
    const res = checkRestrictionsCore({ date, regionChain: chain, vehicle: { plate: v.plate, type: v.type as VehicleType, fuel: v.fuel, cc: v.cc } }, cache.get(key)!);
    const prefs = (await db.doc(`users/${uid}`).get()).data()?.notificationPrefs as Prefs | undefined;
    for (const m of dailyMessages(res.hits as any, v.plate, date, prefs)) {
      try { await db.doc(`users/${uid}/notifications/${m.key}`).create({ kind: m.category, level: 'info', body: `${m.title}. ${m.body}`, createdAt: FieldValue.serverTimestamp(), readAt: null }); }
      catch { continue; }                                                                // ya enviado hoy: no se duplica
      if (prefs?.push !== false) { const tk = await tokensOf(uid); if (tk.length) await dropBad(uid, tk, await getMessaging().sendEachForMulticast({ tokens: tk.map(t => t.token), notification: { title: m.title, body: m.body } })); }
    }
  }
});
