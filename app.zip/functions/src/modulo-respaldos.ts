import { onSchedule } from 'firebase-functions/v2/scheduler';
import { defineString } from 'firebase-functions/params';
import { v1 } from '@google-cloud/firestore';
import { getFirestore } from 'firebase-admin/firestore';
const BUCKET = defineString('BACKUP_BUCKET'); // nombre del bucket (sin gs://); debe existir y la cuenta de servicio necesita permisos de exportación
/** Copia diaria completa de Firestore a Cloud Storage. Ver docs/RECUPERACION.md para restaurar. */
export const dailyBackup = onSchedule({ schedule: 'every day 03:00', timeZone: 'America/Bogota', timeoutSeconds: 120 }, async () => {
  const project = process.env.GCLOUD_PROJECT!; const client = new v1.FirestoreAdminClient(); const date = new Date().toISOString().slice(0, 10);
  const [op] = await client.exportDocuments({ name: client.databasePath(project, '(default)'), outputUriPrefix: `gs://${BUCKET.value()}/backups/${date}`, collectionIds: [] });
  await getFirestore().doc(`backup_runs/${date}`).set({ startedAt: new Date().toISOString(), operation: op.name ?? null, destination: `gs://${BUCKET.value()}/backups/${date}` });
});
