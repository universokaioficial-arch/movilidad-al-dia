import { onDocumentWritten, onDocumentCreated } from 'firebase-functions/v2/firestore';
import { onSchedule } from 'firebase-functions/v2/scheduler';
import { onCall, HttpsError } from 'firebase-functions/v2/https';
import { initializeApp } from 'firebase-admin/app';
import { getFirestore, FieldValue } from 'firebase-admin/firestore';
import { getAuth } from 'firebase-admin/auth';
import { getMessaging } from 'firebase-admin/messaging';
import { categoryEnabled } from './notif-core.js';
import { documentStatus, dueAlert, alertText, todayBogota } from './domain.js';

initializeApp();
const db = getFirestore();
const SYSTEM_KEYS = new Set(['status', 'alertsSent', 'updatedAt', 'updatedBy', 'statusCheckedAt']);

export async function audit(entity: string, path: string, before?: any, after?: any) {
  const keys = new Set([...Object.keys(before ?? {}), ...Object.keys(after ?? {})]);
  const changed = [...keys].filter(k => !SYSTEM_KEYS.has(k) && JSON.stringify(before?.[k]) !== JSON.stringify(after?.[k]));
  if (!changed.length) return;
  let action = !before ? 'crear' : after?.archivedAt && !before.archivedAt ? 'eliminar_logico' : 'editar';
  if (before && before.isMain !== after?.isMain) action = 'cambio_vehiculo_principal';
  if (entity === 'documento' && before && changed.some(k => k === 'expiryDate' || k === 'filePath')) action = 'cambio_documento';
  const pick = (o: any) => o && Object.fromEntries(changed.map(k => [k, o[k] ?? null]));
  await db.collection('audit_logs').add({
    actorUid: after?.updatedBy ?? before?.updatedBy ?? null, at: FieldValue.serverTimestamp(),
    entity, action, path, before: pick(before) ?? null, after: pick(after) ?? null,
  });
}

// Perfil nuevo: el backend fija rol, estado y fecha (el cliente no puede).
export const onUserCreated = onDocumentCreated('users/{uid}', async e => {
  const uid = e.params.uid;
  await e.data!.ref.set({ role: 'usuario', accountStatus: 'activa', createdAt: FieldValue.serverTimestamp(), schemaVersion: 1 }, { merge: true });
  const u = await getAuth().getUser(uid);
  if (!u.customClaims?.role) await getAuth().setCustomUserClaims(uid, { ...u.customClaims, role: 'usuario' });
});
export const onUserAudit = onDocumentWritten('users/{uid}', e => audit('perfil', e.document, e.data?.before.data(), e.data?.after.data()));

export const onVehicleWrite = onDocumentWritten('users/{uid}/vehicles/{plate}', async e => {
  const before = e.data?.before.data(), after = e.data?.after.data();
  await audit('vehiculo', e.document, before, after);
  if (after?.archivedAt && after.isMain) { await e.data!.after.ref.update({ isMain: false }); return; } // un vehículo archivado no puede ser el principal
  if (after && !after.archivedAt && !after.isMain) { // sin principal activo => este pasa a serlo
    const mains = await db.collection(`users/${e.params.uid}/vehicles`).where('isMain', '==', true).get();
    if (mains.docs.every(d => d.data().archivedAt)) await e.data!.after.ref.update({ isMain: true });
  }
});

export const onDocumentWrite = onDocumentWritten('users/{uid}/vehicles/{plate}/documents/{docId}', async e => {
  const before = e.data?.before.data(), after = e.data?.after.data();
  await audit('documento', e.document, before, after);
  if (!after) return;
  const status = documentStatus(after as any, todayBogota());
  if (status !== after.status) await e.data!.after.ref.update({ status });
  if (before?.expiryDate && after.expiryDate && before.expiryDate !== after.expiryDate) // historial de renovaciones
    await e.data!.after.ref.collection('renewals').add({ previousExpiry: before.expiryDate, newExpiry: after.expiryDate, previousNumber: before.number ?? null, at: FieldValue.serverTimestamp(), by: after.updatedBy ?? null });
});

// Único camino para cambiar el vehículo principal (garantiza que solo haya uno).
export const setMainVehicle = onCall(async req => {
  const uid = req.auth?.uid; const plate = String(req.data?.plate ?? '');
  if (!uid) throw new HttpsError('unauthenticated', 'Inicia sesión.');
  const col = db.collection(`users/${uid}/vehicles`);
  await db.runTransaction(async tx => {
    const target = await tx.get(col.doc(plate));
    if (!target.exists || target.data()!.archivedAt) throw new HttpsError('not-found', 'Vehículo no encontrado.');
    const mains = await tx.get(col.where('isMain', '==', true));
    mains.docs.filter(d => d.id !== plate).forEach(d => tx.update(d.ref, { isMain: false, updatedBy: uid }));
    tx.update(target.ref, { isMain: true, updatedBy: uid });
  });
  return { ok: true };
});

// Alertas diarias calculadas con las fechas realmente registradas.
export const dailyDocumentAlerts = onSchedule({ schedule: 'every day 07:00', timeZone: 'America/Bogota' }, async () => {
  const today = todayBogota();
  const limit = new Date(Date.parse(today) + 60 * 864e5).toISOString().slice(0, 10);
  const snap = await db.collectionGroup('documents').where('expiryDate', '<=', limit).get(); // requiere fieldOverride (ya incluido)
  for (const d of snap.docs) {
    const x = d.data(); if (x.archivedAt) continue;
    const [, uid, , plate] = d.ref.path.split('/');
    const status = documentStatus(x as any, today);
    const a = dueAlert(x as any, today);
    const upd: any = status !== x.status ? { status } : {};
    if (a && !(x.alertsSent ?? []).includes(a.key)) {
      const user = (await db.doc(`users/${uid}`).get()).data();
      if (categoryEnabled(user?.notificationPrefs, 'documentos')) {
        const body = alertText(x.type, plate, a);
        await db.collection(`users/${uid}/notifications`).add({ kind: 'documento', level: a.level, body, plate, docId: d.id, createdAt: FieldValue.serverTimestamp(), readAt: null });
        if (user?.notificationPrefs?.push !== false) {
          const tokens = (await db.collection(`users/${uid}/devices`).get()).docs.map(t => t.data().token).filter(Boolean);
          if (tokens.length) await getMessaging().sendEachForMulticast({ tokens, notification: { title: 'Movilidad al Día', body } });
        }
      }
      upd.alertsSent = FieldValue.arrayUnion(a.key);
    }
    if (Object.keys(upd).length) await d.ref.update(upd);
  }
});
