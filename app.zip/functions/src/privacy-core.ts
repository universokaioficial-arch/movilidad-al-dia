// Privacidad: reglas puras. Sin dependencias.
const PERSONAL = ['displayName', 'email', 'phone', 'photoURL', 'city', 'department', 'address'] as const;
/** Campos internos que no se entregan en la exportación. */
export function redactForExport(profile: Record<string, unknown>): Record<string, unknown> {
  const { updatedBy, notificationRegions, ...rest } = profile as any; void updatedBy; void notificationRegions; return rest;
}
/** Anonimización: borra datos personales del perfil SIN eliminar el registro ni su historial (política del proyecto: no borrar información). */
export function anonymizedProfilePatch(now: string): Record<string, unknown> {
  return { ...Object.fromEntries(PERSONAL.map(k => [k, null])), displayName: 'Usuario anonimizado', accountStatus: 'anonimizada', anonymizedAt: now, consents: { location: false }, notificationRegions: [], notificationPrefs: { push: false } };
}
export const DELETION_STATUS = ['pendiente', 'en_proceso', 'completada', 'rechazada'] as const;
export const deletionTransition = (from: string, to: string) => ({ pendiente: ['en_proceso', 'rechazada'], en_proceso: ['completada', 'rechazada'], completada: [], rechazada: [] } as Record<string, string[]>)[from]?.includes(to) ?? false;
/** Datos de Firebase Auth para anonimizar sin borrar la cuenta: correo reservado (.invalid, RFC 2606), sin nombre, foto ni teléfono, y deshabilitada. */
export const anonymizedAuthUpdate = (uid: string) => ({ email: `anonimizado-${uid}@anonimizado.invalid`, displayName: null, photoURL: null, phoneNumber: null, disabled: true });
