// Sustitutos de firebase-admin y firebase-functions: el código de functions/ se ejecuta tal cual sobre el servidor propio.
import { getFirestore as gf, FieldValue as FV, registerTrigger, backupTo, DATA_DIR } from '../db.mjs';
import { adminAuth } from '../auth.mjs'; import { mkdirSync } from 'node:fs'; import { join } from 'node:path';
export const initializeApp = () => ({}); export const getFirestore = gf; export const FieldValue = FV; export const getAuth = () => adminAuth;
// Push: no disponible en el servidor propio (los avisos llegan a la bandeja dentro de la app).
export const getMessaging = () => ({ send: async () => 'sin-push', sendEachForMulticast: async m => ({ successCount: 0, failureCount: 0, responses: (m.tokens ?? []).map(() => ({ success: true })) }), subscribeToTopic: async () => ({}), unsubscribeFromTopic: async () => ({}) });
export class HttpsError extends Error { constructor(code, message, details) { super(message); this.code = code; this.details = details; } }
export const onCall = (a, b) => ({ __kind: 'call', run: typeof a === 'function' ? a : b });
export const onDocumentWritten = (pattern, handler) => { registerTrigger('written', pattern, handler); return { __kind: 'trigger' }; };
export const onDocumentCreated = (pattern, handler) => { registerTrigger('created', pattern, handler); return { __kind: 'trigger' }; };
export const onSchedule = (opts, run) => ({ __kind: 'schedule', schedule: typeof opts === 'string' ? opts : opts.schedule, run });
export const defineSecret = name => ({ name, value: () => process.env[name] ?? '' });
export const defineString = (name, o) => ({ name, value: () => process.env[name] ?? o?.default ?? '' });
export const defineBoolean = (name, o) => ({ name, value: () => (process.env[name] !== undefined ? process.env[name] === 'true' : (o?.default ?? false)) });
// Respaldo: copia consistente del archivo de base de datos (VACUUM INTO) en data/backups.
export const v1 = { FirestoreAdminClient: class { databasePath(p, d) { return `projects/${p}/databases/${d}`; }
  async exportDocuments({ outputUriPrefix }) { const dir = join(DATA_DIR, 'backups'); mkdirSync(dir, { recursive: true }); const file = join(dir, `${outputUriPrefix.split('/').pop()}-${Date.now()}.sqlite`); backupTo(file); return [{ name: file }]; } } };
