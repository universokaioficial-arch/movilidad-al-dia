// Port de firestore.rules y storage.rules a JavaScript: decide qué puede leer/escribir cada usuario. Sin dependencias.
const ADMINS = ['super_admin', 'admin'];
const VEHICLE_TYPES = ['automovil', 'motocicleta', 'moto_electrica', 'ciclomotor', 'camioneta', 'camion', 'bus', 'taxi', 'vehiculo_especial', 'otro'];
const DOC_TYPES = ['soat', 'rtm', 'licencia_conduccion', 'tarjeta_propiedad', 'seguro_voluntario', 'otro'];
const USER_LOCKED = ['role', 'accountStatus', 'createdAt', 'schemaVersion'];
/** op: 'read' | 'create' | 'update' | 'delete'. req.data = documento resultante; req.old = documento actual. ctx = {uid, role} o null. */
export function authorize(op, path, ctx, req = {}) {
  const s = path.split('/'), uid = ctx?.uid ?? null, role = ctx?.role ?? '', nd = req.data ?? {}, od = req.old ?? {};
  const signedIn = !!uid, isSuper = signedIn && role === 'super_admin', isAdmin = signedIn && ADMINS.includes(role), isOwner = u => signedIn && uid === u, read = op === 'read';
  const stamped = () => nd.updatedBy === uid;
  const affected = () => [...new Set([...Object.keys(nd), ...Object.keys(od)])].filter(k => JSON.stringify(nd[k]) !== JSON.stringify(od[k]));
  const blocked = keys => !affected().some(k => keys.includes(k));
  if (path.split('/').some(x => !x)) return false;
  if (s[0] === 'users') {
    const u = s[1];
    if (s.length === 2) {
      if (read) return isOwner(u) || isAdmin;
      if (op === 'create') return isOwner(u) && stamped() && !USER_LOCKED.some(k => k in nd);
      if (op === 'update') return (isOwner(u) || isAdmin) && stamped() && blocked(USER_LOCKED);   // rol/estado solo los cambia el servidor; la auditoría no se falsea
      return false;                                                                                  // nunca se borran usuarios
    }
    const sub = s[2], oa = isOwner(u) || isAdmin;
    if (sub === 'vehicles') {
      if (s.length === 4) {
        if (read) return oa;
        if (op === 'create') return oa && stamped() && VEHICLE_TYPES.includes(nd.type) && /^[A-Z0-9]{5,7}$/.test(s[3]) && nd.plate === s[3] && nd.isMain === false;
        if (op === 'update') return oa && stamped() && VEHICLE_TYPES.includes(nd.type) && nd.plate === od.plate && blocked(['isMain']);
        return false;                                                                                // borrado lógico (archivedAt)
      }
      if (s[4] === 'documents' && s.length === 6) {
        if (read) return oa;
        if (op === 'create') return oa && stamped() && DOC_TYPES.includes(nd.type) && !('status' in nd) && !('alertsSent' in nd);
        if (op === 'update') return oa && stamped() && DOC_TYPES.includes(nd.type) && blocked(['status', 'alertsSent']);
        return false;
      }
      if (s[4] === 'documents' && s[6] === 'renewals' && s.length === 8) return read && oa;
      return false;
    }
    if (s.length === 4) {
      if (sub === 'notifications') return read ? isOwner(u) : op === 'update' && isOwner(u) && affected().every(k => k === 'readAt');
      if (sub === 'devices') return isOwner(u);
      if (['favorites', 'trips', 'kai_history'].includes(sub)) return op !== 'delete' && oa;
    }
    return false;
  }
  if (s.length !== 2) return false;
  switch (s[0]) {
    case 'regions': return read;                                                      // se escriben vía saveRegion
    case 'pico_placa_rules': return read || isAdmin;
    case 'mobility_rules': case 'news': case 'alerts': case 'directory': return read && (od.status === 'publicada' || isAdmin);
    case 'app_config': return read || isSuper;
    case 'reports': return read && (isOwner(od.authorId) || isAdmin);
    case 'public_reports': return read && od.status === 'verificado';
    case 'deletion_requests': case 'audit_logs': return read && isSuper;
    default: return false;                                                            // todo lo demás: denegado
  }
}
/** Archivos (equivale a storage.rules). meta = {size, type}. */
export function authorizeFile(op, path, ctx, meta = {}, exists = false) {
  const s = path.split('/'), uid = ctx?.uid ?? null, admin = !!uid && ADMINS.includes(ctx.role), owner = u => !!uid && uid === u, MB10 = 10 * 1024 * 1024;
  if (s.some(x => !x || x === '..' || x === '.') || s.length < 3) return false;
  if (s[0] === 'users') { if (op === 'read') return owner(s[1]) || admin; return op !== 'delete' && owner(s[1]) && meta.size < MB10 && /^(image\/.+|application\/pdf)$/.test(meta.type ?? ''); }
  if (s[0] === 'reports') { if (op === 'read') return admin; return op === 'write' && !exists && owner(s[1]) && meta.size < MB10 && /^image\/.+/.test(meta.type ?? ''); }
  return false;
}
