// Utilidades de administración.  Uso:
//   node --import ./server/register.mjs server/cli.mjs set-super-admin correo@ejemplo.com
//   node --import ./server/register.mjs server/cli.mjs run-job dailyBackup
import { adminAuth } from './auth.mjs'; import { setSync, settle } from './db.mjs'; import { setJobs, runJob } from './jobs.mjs';
const [cmd, arg] = process.argv.slice(2);
if (cmd === 'set-super-admin') {
  const u = await adminAuth.getUserByEmail(arg).catch(() => null); if (!u) { console.error('Ese correo no está registrado: primero crea la cuenta en la app.'); process.exit(1); }
  await adminAuth.setCustomUserClaims(u.uid, { ...u.customClaims, role: 'super_admin' }); setSync(`users/${u.uid}`, { role: 'super_admin', updatedBy: 'cli:set-super-admin' }, { merge: true }); await adminAuth.revokeRefreshTokens(u.uid); await settle();
  console.log('Listo. Cierra sesión y vuelve a entrar para que el rol tome efecto.');
} else if (cmd === 'run-job') {
  process.env.GCLOUD_PROJECT ??= 'movilidad-propio'; const ns = await import('../functions/src/index.ts'); setJobs(new Map(Object.entries(ns).filter(([, v]) => v?.__kind === 'schedule'))); await runJob(arg); await settle(); console.log('Tarea completada:', arg);
} else console.log('Comandos: set-super-admin <correo> | run-job <nombre>');
