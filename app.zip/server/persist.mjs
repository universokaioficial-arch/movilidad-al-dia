// Persistencia en almacenamiento compatible con S3 (Backblaze B2, Cloudflare R2, Supabase Storage, MinIO…) para hostings con disco NO permanente.
// Al arrancar sin base local se restaura la última copia; cada pocos minutos (si hubo cambios) y al apagarse se sube una copia nueva. Sin dependencias.
import { createHash, createHmac } from 'node:crypto'; import { existsSync, mkdirSync, readFileSync, writeFileSync, rmSync } from 'node:fs'; import { join } from 'node:path'; import { tmpdir } from 'node:os';
const E = () => process.env;
export const enabled = () => !!(E().S3_ENDPOINT && E().S3_BUCKET && E().S3_ACCESS_KEY && E().S3_SECRET_KEY);
const hex = d => createHash('sha256').update(d).digest('hex'); const mac = (k, d) => createHmac('sha256', k).update(d).digest();
const enc = s => encodeURIComponent(s).replace(/[!'()*]/g, c => '%' + c.charCodeAt(0).toString(16).toUpperCase());
/** Firma AWS Signature V4 (la que usan todos los servicios S3). */
export function signV4({ method, url, headers = {}, body = Buffer.alloc(0), region, service = 's3', accessKey, secretKey, now = new Date(), payloadHeader = true }) {
  const u = new URL(url), amz = now.toISOString().replace(/[:-]|\.\d{3}/g, ''), date = amz.slice(0, 8), payload = hex(body);
  const h = { ...Object.fromEntries(Object.entries(headers).map(([k, v]) => [k.toLowerCase(), String(v).trim()])), host: u.host, 'x-amz-date': amz }; if (payloadHeader) h['x-amz-content-sha256'] = payload;
  const names = Object.keys(h).sort(), signed = names.join(';'), canonUri = u.pathname.split('/').map(seg => enc(decodeURIComponent(seg))).join('/') || '/';
  const canonQuery = [...u.searchParams].map(([k, v]) => [enc(k), enc(v)]).sort((a, b) => (a[0] === b[0] ? (a[1] < b[1] ? -1 : 1) : a[0] < b[0] ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('&');
  const canonical = [method, canonUri, canonQuery, names.map(n => `${n}:${h[n]}\n`).join(''), signed, payload].join('\n'); const scope = `${date}/${region}/${service}/aws4_request`;
  const sts = ['AWS4-HMAC-SHA256', amz, scope, hex(canonical)].join('\n'); const key = mac(mac(mac(mac('AWS4' + secretKey, date), region), service), 'aws4_request');
  return { ...h, Authorization: `AWS4-HMAC-SHA256 Credential=${accessKey}/${scope}, SignedHeaders=${signed}, Signature=${createHmac('sha256', key).update(sts).digest('hex')}` };
}
async function req(method, key, body, type) {
  const e = E(), url = `${e.S3_ENDPOINT.replace(/\/$/, '')}/${e.S3_BUCKET}/${key.split('/').map(encodeURIComponent).join('/')}`;
  const h = signV4({ method, url, body: body ?? Buffer.alloc(0), region: e.S3_REGION || 'us-east-1', accessKey: e.S3_ACCESS_KEY, secretKey: e.S3_SECRET_KEY, headers: type ? { 'content-type': type } : {} }); delete h.host;   // fetch pone el Host
  return fetch(url, { method, headers: h, body });
}
export async function put(key, buf, type = 'application/octet-stream') { const r = await req('PUT', key, buf, type); if (!r.ok) throw new Error(`S3 PUT ${key}: ${r.status}`); }
export async function get(key) { const r = await req('GET', key); if (r.status === 404) return null; if (!r.ok) throw new Error(`S3 GET ${key}: ${r.status}`); return Buffer.from(await r.arrayBuffer()); }
export const putFile = (path, buf, type) => (enabled() ? put('files/' + encodeURIComponent(path), buf, type) : Promise.resolve());
export const getFile = path => (enabled() ? get('files/' + encodeURIComponent(path)) : Promise.resolve(null));
/** Antes de abrir la base: si no hay base local y existe copia remota, se restaura. 'error' = NO arrancar (para no sobrescribir la copia buena con una base vacía). */
export async function restoreIfEmpty() {
  if (!enabled()) return 'desactivado'; const dir = E().DATA_DIR ?? join(process.cwd(), 'data'), file = join(dir, E().DB_FILE ?? 'mm.sqlite'); if (existsSync(file)) return 'local';
  try { const b = await get('db/latest.sqlite'); if (!b) return 'sin-copia'; mkdirSync(dir, { recursive: true }); writeFileSync(file, b); return 'restaurada'; } catch (e) { console.error('[persistencia] no se pudo restaurar:', e.message); return 'error'; }
}
let lastChanges = -1;
export async function snapshotNow({ backupTo, changes }, force = false) {
  if (!enabled()) return false; const n = changes(); if (!force && n === lastChanges) return false;
  const tmp = join(tmpdir(), `mm-snap-${process.pid}.sqlite`); rmSync(tmp, { force: true }); backupTo(tmp); const buf = readFileSync(tmp); rmSync(tmp, { force: true });
  await put(`db/${new Date().toISOString().slice(0, 10)}.sqlite`, buf, 'application/x-sqlite3'); await put('db/latest.sqlite', buf, 'application/x-sqlite3'); lastChanges = n; return true;   // primero la copia del día; «latest» al final
}
export function startSnapshots(deps, minutes = Number(E().SNAPSHOT_MINUTES ?? 5)) {
  if (!enabled()) return; const t = setInterval(() => snapshotNow(deps).catch(e => console.error('[persistencia]', e.message)), minutes * 60e3); t.unref();
  for (const sig of ['SIGTERM', 'SIGINT']) process.on(sig, async () => { try { await snapshotNow(deps, true); console.log('[persistencia] copia final subida'); } catch (e) { console.error('[persistencia]', e.message); } process.exit(0); });   // el hosting avisa antes de apagar
}
