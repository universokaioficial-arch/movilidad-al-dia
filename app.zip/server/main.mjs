// Arranque:  node --import ./server/register.mjs server/main.mjs
import { startScheduler } from './jobs.mjs'; import { restoreIfEmpty, startSnapshots, enabled } from './persist.mjs';
process.env.GCLOUD_PROJECT ??= 'movilidad-propio';
const st = await restoreIfEmpty();                       // antes de abrir la base
if (st === 'error') { console.error('No se pudo leer la copia de seguridad: no se arranca para no perder datos. Revisa las variables S3_*.'); process.exit(1); }
if (enabled()) console.log(`[persistencia] copia en S3: ${st}`);
const { buildApp } = await import('./app.mjs'); const { sqlite, backupTo } = await import('./db.mjs');
const app = buildApp(); await app.loadFunctions(await import('../functions/src/index.ts'));   // se carga el MISMO código de functions/
const port = Number(process.env.PORT ?? 8080); app.server.listen(port, () => console.log(`Movilidad al Día · servidor propio en http://localhost:${port}  (${app.calls.size} funciones, ${app.jobs.size} tareas)`));
startScheduler(); startSnapshots({ backupTo, changes: () => sqlite.prepare('SELECT total_changes() AS n').get().n });
