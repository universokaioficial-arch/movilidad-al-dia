import { pathToFileURL, fileURLToPath } from 'node:url'; import { existsSync } from 'node:fs';
const SHIM = new URL('./shims/firebase.mjs', import.meta.url).href;
const MAP = new Set(['firebase-admin/app', 'firebase-admin/firestore', 'firebase-admin/auth', 'firebase-admin/messaging', 'firebase-functions/v2/https', 'firebase-functions/v2/firestore', 'firebase-functions/v2/scheduler', 'firebase-functions/params', '@google-cloud/firestore']);
export async function resolve(specifier, context, next) {
  if (MAP.has(specifier)) return { url: SHIM, shortCircuit: true };                                       // Firebase → servidor propio
  if (specifier.startsWith('.') && specifier.endsWith('.js') && context.parentURL?.startsWith('file:')) {  // './x.js' → './x.ts' (el código fuente está en TypeScript)
    const p = fileURLToPath(new URL(specifier, context.parentURL));
    if (!existsSync(p) && existsSync(p.slice(0, -3) + '.ts')) return next(pathToFileURL(p.slice(0, -3) + '.ts').href, context);
  }
  return next(specifier, context);
}
