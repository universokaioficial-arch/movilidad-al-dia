// Servidor HTTP: autenticación, datos, funciones, archivos y la app web. Solo Node 22+, sin dependencias.
import { createServer } from 'node:http'; import { readFileSync, existsSync, writeFileSync, mkdirSync, statSync, createReadStream } from 'node:fs'; import { join, extname, resolve as presolve } from 'node:path';
import * as A from './auth.mjs'; import { DATA_DIR, Query, readSync, setSync, updateSync, deleteSync, deepMerge, sqlite, getFirestore } from './db.mjs';
import { authorize, authorizeFile } from './policy.mjs'; import * as P from './persist.mjs'; import { HttpsError } from './shims/firebase.mjs'; import { setJobs } from './jobs.mjs';
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.webmanifest': 'application/manifest+json', '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8' };
const STATUS = { unauthenticated: 401, 'permission-denied': 403, 'not-found': 404, 'invalid-argument': 400, 'failed-precondition': 400, 'already-exists': 409, 'resource-exhausted': 429, unavailable: 503, 'out-of-range': 400 };
const SEC = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'Permissions-Policy': 'geolocation=(self), microphone=(self), camera=(self)', 'X-Frame-Options': 'DENY' };
const hits = new Map();
function limited(key, max, ms) { const n = Date.now(), h = hits.get(key); if (!h || h.reset < n) { hits.set(key, { c: 1, reset: n + ms }); return false; } return ++h.c > max; }
const send = (res, code, body, headers = {}) => { res.writeHead(code, { ...SEC, ...headers }); res.end(body); };
const json = (res, code, obj) => send(res, code, JSON.stringify(obj), { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
const fail = (res, e) => { const code = e.code ?? 'internal'; json(res, e instanceof A.AuthError ? 400 : (STATUS[code] ?? 500), { error: { code, message: e.message } }); if (!STATUS[code] && !(e instanceof A.AuthError)) console.error(e); };
async function body(req, max) { const chunks = []; let n = 0; for await (const c of req) { n += c.length; if (n > max) throw new HttpsError('invalid-argument', 'Contenido demasiado grande.'); chunks.push(c); } return Buffer.concat(chunks); }
const readJson = async (req, max = 1e6) => { const b = await body(req, max); try { return b.length ? JSON.parse(b) : {}; } catch { throw new HttpsError('invalid-argument', 'JSON inválido.'); } };
const hasSentinel = v => v && typeof v === 'object' && ('__fv' in v || Object.values(v).some(hasSentinel));

export function buildApp({ staticDir = presolve('apps/web/dist'), publicUrl = process.env.PUBLIC_URL ?? `http://localhost:${process.env.PORT ?? 8080}` } = {}) {
  const calls = new Map(), jobs = new Map();
  const filesDir = join(DATA_DIR, 'files'); mkdirSync(filesDir, { recursive: true });
  const fileOnDisk = p => join(filesDir, encodeURIComponent(p));
  async function loadFunctions(ns) { for (const [name, v] of Object.entries(ns)) { if (v?.__kind === 'call') calls.set(name, v.run); if (v?.__kind === 'schedule') jobs.set(name, v); } setJobs(jobs); }

  async function authRoutes(req, res, path, url) {
    const ip = req.socket.remoteAddress ?? '?'; if (limited(`a:${ip}`, 60, 60e3)) throw new HttpsError('resource-exhausted', 'Demasiados intentos. Espera un minuto.');
    if (req.method === 'GET' && path === '/auth/verify') { try { A.markVerified(A.consumeToken('verify', url.searchParams.get('token'))); send(res, 302, '', { Location: '/?verified=1' }); } catch { send(res, 302, '', { Location: '/?verified=0' }); } return; }
    const b = await readJson(req);
    if (path === '/auth/register') { const u = A.createUser({ email: b.email, password: b.password, displayName: b.displayName ?? null }); A.sendMail({ to: u.email, subject: 'Verifica tu correo · Movilidad al Día', text: `Abre este enlace para verificar tu correo:\n${publicUrl}/auth/verify?token=${A.makeToken('verify', u.uid, 3 * 864e5)}` }).catch(console.error); return json(res, 200, A.issueTokens(u.uid)); }
    if (path === '/auth/login') { if (limited(`l:${String(b.email).toLowerCase()}`, 10, 600e3)) throw new HttpsError('resource-exhausted', 'Demasiados intentos para este correo.'); return json(res, 200, A.login(b.email, b.password)); }
    if (path === '/auth/refresh') return json(res, 200, A.refreshSession(b.refresh));
    if (path === '/auth/logout') { A.logout(b.refresh); return json(res, 200, { ok: true }); }
    if (path === '/auth/google') return json(res, 200, A.loginWithGoogle(await A.verifyGoogleIdToken(b.idToken, process.env.GOOGLE_CLIENT_ID)));
    if (path === '/auth/reset-request') { const u = A.userByEmail(b.email ?? ''); if (u) A.sendMail({ to: u.email, subject: 'Recupera tu contraseña · Movilidad al Día', text: `Abre este enlace para elegir una contraseña nueva (vence en 1 hora):\n${publicUrl}/?reset=${A.makeToken('reset', u.uid, 3600e3)}` }).catch(console.error); return json(res, 200, { ok: true }); } // misma respuesta exista o no el correo
    if (path === '/auth/reset') { A.setPassword(A.consumeToken('reset', b.token), b.password); return json(res, 200, { ok: true }); }
    if (path === '/auth/verify-request') { const c = A.authenticate(req.headers.authorization); if (!c) throw new HttpsError('unauthenticated', 'Inicia sesión.'); const u = A.userById(c.uid); await A.sendMail({ to: u.email, subject: 'Verifica tu correo · Movilidad al Día', text: `${publicUrl}/auth/verify?token=${A.makeToken('verify', u.uid, 3 * 864e5)}` }); return json(res, 200, { ok: true }); }
    throw new HttpsError('not-found', 'Ruta no encontrada.');
  }
  async function dbRoutes(req, res, path, url, ctx) {
    const get = k => url.searchParams.get(k);
    if (req.method === 'GET' && path === '/db/doc') { const p = get('path') ?? ''; if (p.split('/').length % 2) throw new HttpsError('invalid-argument', 'Ruta de documento inválida.'); const d = readSync(p);
      if (!authorize('read', p, ctx, { old: d ?? {} })) throw new HttpsError('permission-denied', 'Sin permiso.'); if (!d) throw new HttpsError('not-found', 'No existe.'); return json(res, 200, { path: p, id: p.split('/').pop(), data: d }); }
    if (req.method === 'GET' && path === '/db/list') {
      const p = get('path') ?? ''; if (!p || p.split('/').length % 2 === 0) throw new HttpsError('invalid-argument', 'Ruta de colección inválida.');
      let q = new Query(p); const w = get('where') ? JSON.parse(get('where')) : []; for (const [f, op, v] of w) q = q.where(f, op, v);
      if (get('orderBy')) q = q.orderBy(get('orderBy'), get('dir') === 'desc' ? 'desc' : 'asc'); q = q.limit(Math.min(Number(get('limit') ?? 500), 500));
      const docs = (await q.get()).docs.filter(d => authorize('read', d.ref.path, ctx, { old: d.data() })).map(d => ({ id: d.id, path: d.ref.path, data: d.data() }));   // solo se devuelve lo que el usuario puede leer
      return json(res, 200, { docs }); }
    if (req.method !== 'POST') throw new HttpsError('not-found', 'Ruta no encontrada.');
    const b = await readJson(req); const p = String(b.path ?? ''); if (p.split('/').length % 2) throw new HttpsError('invalid-argument', 'Ruta de documento inválida.');
    if (path === '/db/delete') { if (!authorize('delete', p, ctx, { old: readSync(p) ?? {} })) throw new HttpsError('permission-denied', 'Sin permiso.'); deleteSync(p); return json(res, 200, { ok: true }); }
    if (!b.data || typeof b.data !== 'object' || Array.isArray(b.data) || hasSentinel(b.data)) throw new HttpsError('invalid-argument', 'Datos inválidos.');
    const old = readSync(p);
    if (path === '/db/set') { const nd = b.merge ? deepMerge(old ?? {}, b.data) : b.data; if (!authorize(old ? 'update' : 'create', p, ctx, { data: nd, old: old ?? {} })) throw new HttpsError('permission-denied', 'Sin permiso.'); setSync(p, b.data, { merge: !!b.merge }); return json(res, 200, { ok: true }); }
    if (path === '/db/update') { if (!old) throw new HttpsError('not-found', 'No existe.'); if (Object.keys(b.data).some(k => k.includes('.'))) throw new HttpsError('invalid-argument', 'Claves con punto no permitidas.');
      if (!authorize('update', p, ctx, { data: { ...old, ...b.data }, old })) throw new HttpsError('permission-denied', 'Sin permiso.'); updateSync(p, b.data); return json(res, 200, { ok: true }); }
    throw new HttpsError('not-found', 'Ruta no encontrada.');
  }
  async function fnRoute(req, res, name, ctx) {
    const run = calls.get(name); if (!run) throw new HttpsError('not-found', 'Función no encontrada.'); const b = await readJson(req);
    const r = await run({ auth: ctx ? { uid: ctx.uid, token: ctx.token } : undefined, data: b.data, app: { appId: 'servidor-propio' } }); return json(res, 200, { result: r ?? null });
  }
  async function fileRoutes(req, res, path, url, ctx) {
    if (req.method === 'POST' && path === '/files-url') { const b = await readJson(req); if (!authorizeFile('read', String(b.path), ctx)) throw new HttpsError('permission-denied', 'Sin permiso.'); return json(res, 200, { url: `/files/${String(b.path).split('/').map(encodeURIComponent).join('/')}?t=${A.signJwt({ file: b.path, exp: Date.now() + 600e3 })}` }); }
    const p = decodeURIComponent(path.slice('/files/'.length)).split('/').map(x => x).join('/');
    if (req.method === 'PUT') { const type = (req.headers['content-type'] ?? '').split(';')[0], exists = !!sqlite.prepare('SELECT 1 FROM files WHERE path=?').get(p); const buf = await body(req, 10 * 1024 * 1024);
      if (!authorizeFile('write', p, ctx, { size: buf.length, type }, exists)) throw new HttpsError('permission-denied', 'Sin permiso o archivo no permitido.'); writeFileSync(fileOnDisk(p), buf); await P.putFile(p, buf, type).catch(e => console.error('[persistencia] archivo', e.message));   // copia fuera del disco temporal
      sqlite.prepare('INSERT INTO files(path,type,size,updated) VALUES(?,?,?,?) ON CONFLICT(path) DO UPDATE SET type=excluded.type,size=excluded.size,updated=excluded.updated').run(p, type, buf.length, new Date().toISOString()); return json(res, 200, { path: p }); }
    if (req.method === 'GET') { const t = url.searchParams.get('t'); const tok = t && A.verifyJwt(t); const ok = (tok && tok.file === p) || authorizeFile('read', p, ctx); if (!ok) throw new HttpsError('permission-denied', 'Sin permiso.');
      const m = sqlite.prepare('SELECT * FROM files WHERE path=?').get(p); if (m && !existsSync(fileOnDisk(p))) { const b = await P.getFile(p).catch(() => null); if (b) writeFileSync(fileOnDisk(p), b); }   // tras un reinicio se recupera de la copia
      if (!m || !existsSync(fileOnDisk(p))) throw new HttpsError('not-found', 'No existe.');
      res.writeHead(200, { ...SEC, 'Content-Type': m.type, 'Content-Length': m.size, 'Cache-Control': 'private, max-age=300', 'Content-Security-Policy': 'sandbox' }); return createReadStream(fileOnDisk(p)).pipe(res); }
    throw new HttpsError('not-found', 'Ruta no encontrada.');
  }
  function serveStatic(req, res, path) {
    if (path === '/config.js') { const e = { PROD: true, BACKEND: 'selfhost', VITE_GOOGLE_MAPS_BROWSER_KEY: process.env.GOOGLE_MAPS_BROWSER_KEY ?? '', VITE_GOOGLE_CLIENT_ID: process.env.GOOGLE_CLIENT_ID ?? '' }; return send(res, 200, `window.__MM_ENV__ = ${JSON.stringify(e)};`, { 'Content-Type': MIME['.js'], 'Cache-Control': 'no-store' }); }
    let f = presolve(join(staticDir, decodeURIComponent(path))); if (!f.startsWith(presolve(staticDir))) return send(res, 403, 'Prohibido');
    if (existsSync(f) && statSync(f).isDirectory()) f = join(f, 'index.html');
    if (!existsSync(f)) { if (extname(path)) return send(res, 404, 'No encontrado'); f = join(staticDir, path.startsWith('/admin') ? 'admin/index.html' : 'index.html'); }   // la app es de una sola página
    if (!existsSync(f)) return send(res, 404, 'Falta compilar la app: bash scripts/build-static.sh');
    const hashed = path.includes('/assets/'), noCache = ['/sw.js', '/sw-core.js', '/manifest.webmanifest', '/precache-manifest.json'].includes(path) || f.endsWith('index.html');
    res.writeHead(200, { ...SEC, 'Content-Type': MIME[extname(f)] ?? 'application/octet-stream', 'Cache-Control': noCache ? 'no-cache' : hashed ? 'public, max-age=31536000, immutable' : 'public, max-age=3600', ...(path === '/sw.js' ? { 'Service-Worker-Allowed': '/' } : {}) });
    if (req.method === 'HEAD') return res.end(); createReadStream(f).pipe(res);
  }
  const server = createServer(async (req, res) => {
    try {
      const url = new URL(req.url, 'http://x'), path = url.pathname; const ctx = A.authenticate(req.headers.authorization);
      if (path === '/health') return json(res, 200, { ok: true });
      if (path.startsWith('/auth/')) return await authRoutes(req, res, path, url);
      if (path.startsWith('/db/')) return await dbRoutes(req, res, path, url, ctx);
      if (path.startsWith('/fn/') && req.method === 'POST') return await fnRoute(req, res, path.slice(4), ctx);
      if (path.startsWith('/files') && (path === '/files-url' || path.startsWith('/files/'))) return await fileRoutes(req, res, path, url, ctx);
      if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'Método no permitido');
      serveStatic(req, res, path);
    } catch (e) { if (!res.headersSent) fail(res, e); else res.end(); }
  });
  return { server, loadFunctions, calls, jobs, db: getFirestore() };
}
