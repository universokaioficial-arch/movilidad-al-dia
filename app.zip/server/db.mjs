// Base de documentos compatible con la API de Firestore que usa el código de functions/, sobre SQLite (node:sqlite). Sin dependencias.
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs'; import { join } from 'node:path'; import { randomBytes } from 'node:crypto';
export const DATA_DIR = process.env.DATA_DIR ?? join(process.cwd(), 'data');
mkdirSync(DATA_DIR, { recursive: true });
export const sqlite = new DatabaseSync(join(DATA_DIR, process.env.DB_FILE ?? 'mm.sqlite'));
sqlite.exec(`PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS docs (path TEXT PRIMARY KEY, coll TEXT NOT NULL, parent TEXT NOT NULL, data TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS docs_coll ON docs(coll); CREATE INDEX IF NOT EXISTS docs_parent ON docs(parent);
CREATE TABLE IF NOT EXISTS users (uid TEXT PRIMARY KEY, email TEXT UNIQUE, pass TEXT, display_name TEXT, photo TEXT, phone TEXT, verified INTEGER DEFAULT 0, disabled INTEGER DEFAULT 0, claims TEXT DEFAULT '{}', valid_after INTEGER DEFAULT 0, created TEXT, google_sub TEXT);
CREATE TABLE IF NOT EXISTS refresh (hash TEXT PRIMARY KEY, uid TEXT, exp INTEGER);
CREATE TABLE IF NOT EXISTS tokens (hash TEXT PRIMARY KEY, kind TEXT, uid TEXT, exp INTEGER);
CREATE TABLE IF NOT EXISTS files (path TEXT PRIMARY KEY, type TEXT, size INTEGER, updated TEXT);`);

const clone = v => (v === undefined ? undefined : JSON.parse(JSON.stringify(v)));
const same = (a, b) => JSON.stringify(a) === JSON.stringify(b);
const getPath = (o, p) => p.split('.').reduce((x, k) => (x == null ? undefined : x[k]), o);
function applyFV(val, old) {                                   // resuelve marcadores: serverTimestamp, arrayUnion, delete
  if (val && val.__fv === 'ts') return new Date().toISOString();
  if (val && val.__fv === 'union') { const o = Array.isArray(old) ? old : []; return [...o, ...val.values.filter(v => !o.some(x => same(x, v)))]; }
  if (Array.isArray(val)) return val.map(v => applyFV(v));
  if (val && typeof val === 'object') return Object.fromEntries(Object.entries(val).filter(([, v]) => !(v && v.__fv === 'del')).map(([k, v]) => [k, applyFV(v, old?.[k])]));
  return val;
}
export const deepMerge = (a, b) => { const o = { ...a }; for (const [k, v] of Object.entries(b)) o[k] = v && typeof v === 'object' && !Array.isArray(v) && o[k] && typeof o[k] === 'object' && !Array.isArray(o[k]) ? deepMerge(o[k], v) : v; return o; };
const collOf = path => { const s = path.split('/'); return { coll: s[s.length - 2], parent: s.slice(0, -1).join('/') }; };
export const FieldValue = { serverTimestamp: () => ({ __fv: 'ts' }), arrayUnion: (...values) => ({ __fv: 'union', values }), delete: () => ({ __fv: 'del' }) };
const dbErr = (code, msg) => Object.assign(new Error(msg), { code });

// ---------- Disparadores (equivalente a onDocumentWritten / onDocumentCreated) ----------
const triggers = []; const pendingEvents = []; const running = new Set(); let queued = false;
export const registerTrigger = (kind, pattern, handler) => { const names = []; const re = new RegExp('^' + pattern.replace(/\{(\w+)\}/g, (_, n) => (names.push(n), '([^/]+)')) + '$'); triggers.push({ kind, re, names, handler }); };
function snap(path, data) { return new DocSnap(path, data ?? null); }
function flush() {
  if (queued) return; queued = true;
  setImmediate(() => { queued = false; const evs = pendingEvents.splice(0);
    for (const ev of evs) { if (same(ev.before, ev.after)) continue;
      for (const t of triggers) { const m = ev.path.match(t.re); if (!m) continue; if (t.kind === 'created' && !(ev.before == null && ev.after != null)) continue;
        const params = Object.fromEntries(t.names.map((n, i) => [n, m[i + 1]]));
        const e = t.kind === 'created' ? { params, document: ev.path, data: snap(ev.path, ev.after) } : { params, document: ev.path, data: { before: snap(ev.path, ev.before), after: snap(ev.path, ev.after) } };
        const p = Promise.resolve().then(() => t.handler(e)).catch(err => console.error(`[disparador ${ev.path}]`, err)).finally(() => running.delete(p)); running.add(p); } } });
}
export async function settle() { for (let i = 0; i < 400; i++) { if (!queued && !pendingEvents.length && !running.size) return; await new Promise(r => setTimeout(r, 5)); } }

// ---------- Lectura/escritura síncrona (base de las transacciones) ----------
export const readSync = path => { const r = sqlite.prepare('SELECT data FROM docs WHERE path=?').get(path); return r ? JSON.parse(r.data) : null; };
function writeSync(path, data) {
  const before = readSync(path);
  if (data === null) sqlite.prepare('DELETE FROM docs WHERE path=?').run(path);
  else { const { coll, parent } = collOf(path); sqlite.prepare('INSERT INTO docs(path,coll,parent,data) VALUES(?,?,?,?) ON CONFLICT(path) DO UPDATE SET data=excluded.data').run(path, coll, parent, JSON.stringify(data)); }
  pendingEvents.push({ path, before, after: data }); flush();
}
export function setSync(path, data, opts) { const old = readSync(path); const res = applyFV(data, old ?? undefined); writeSync(path, opts?.merge ? deepMerge(old ?? {}, res) : res); }
export function updateSync(path, data) {
  const old = readSync(path); if (!old) throw dbErr('not-found', `NOT_FOUND: no existe ${path}`); const next = clone(old);
  for (const [k, v] of Object.entries(data)) { const keys = k.split('.'); let o = next; for (const kk of keys.slice(0, -1)) o = o[kk] ??= {}; const last = keys[keys.length - 1];
    if (v && v.__fv === 'del') delete o[last]; else o[last] = applyFV(v, o[last]); }
  writeSync(path, next);
}
export function createSync(path, data) { if (readSync(path)) throw dbErr('already-exists', `ALREADY_EXISTS: ${path}`); writeSync(path, applyFV(data)); }
export const deleteSync = path => writeSync(path, null);

export class DocSnap {
  constructor(path, data) { this.ref = new DocRef(path); this.id = this.ref.id; this._d = data; this.exists = data != null; }
  data() { return this._d == null ? undefined : clone(this._d); }
}
export class DocRef {
  constructor(path) { this.path = path; this.id = path.split('/').pop(); }
  collection(name) { return new Query(this.path + '/' + name); }
  get parent() { return new Query(this.path.split('/').slice(0, -1).join('/')); }
  async get() { return new DocSnap(this.path, readSync(this.path)); }
  async set(d, o) { setSync(this.path, d, o); }
  async update(d) { updateSync(this.path, d); }
  async create(d) { createSync(this.path, d); }
  async delete() { deleteSync(this.path); }
}
const eq = (a, b) => (a && typeof a === 'object') || (b && typeof b === 'object') ? same(a, b) : a === b;
function matches(val, op, v) {
  const ord = typeof val === typeof v && (typeof val === 'string' || typeof val === 'number');
  switch (op) { case '==': return val !== undefined && eq(val, v); case '!=': return val !== undefined && !eq(val, v); case 'in': return val !== undefined && v.some(x => eq(val, x));
    case 'array-contains': return Array.isArray(val) && val.some(x => eq(x, v)); case '<': return ord && val < v; case '<=': return ord && val <= v; case '>': return ord && val > v; case '>=': return ord && val >= v; }
  throw new Error('Operador no soportado: ' + op);
}
const cmp = (a, b) => (a === b ? 0 : a === null ? -1 : b === null ? 1 : a < b ? -1 : 1);
export class QuerySnap { constructor(docs) { this.docs = docs; this.size = docs.length; this.empty = !docs.length; } forEach(f) { this.docs.forEach(f); } }
export class Query {
  constructor(coll, group = false, filters = [], order = null, lim = null) { this.coll = coll; this.group = group; this.filters = filters; this.order = order; this.lim = lim; }
  where(f, op, v) { return new Query(this.coll, this.group, [...this.filters, [f, op, v]], this.order, this.lim); }
  orderBy(f, dir = 'asc') { return new Query(this.coll, this.group, this.filters, [f, dir], this.lim); }
  limit(n) { return new Query(this.coll, this.group, this.filters, this.order, n); }
  doc(id) { return new DocRef(this.coll + '/' + (id ?? randomBytes(10).toString('hex'))); }
  _run() {
    const rows = this.group ? sqlite.prepare('SELECT path,data FROM docs WHERE coll=?').all(this.coll) : sqlite.prepare('SELECT path,data FROM docs WHERE parent=?').all(this.coll);
    let docs = rows.map(r => ({ path: r.path, data: JSON.parse(r.data) })).filter(d => this.filters.every(([f, op, v]) => matches(getPath(d.data, f), op, v)));
    if (this.order) { const [f, dir] = this.order; docs = docs.filter(d => getPath(d.data, f) !== undefined).sort((a, b) => cmp(getPath(a.data, f), getPath(b.data, f)) * (dir === 'desc' ? -1 : 1)); }
    return this.lim != null ? docs.slice(0, this.lim) : docs;
  }
  async get() { return new QuerySnap(this._run().map(d => new DocSnap(d.path, d.data))); }
  count() { return { get: async () => ({ data: () => ({ count: this._run().length }) }) }; }
  async add(data) { const ref = this.doc(); await ref.set(data); return ref; }
}
// ---------- Transacciones: se serializan y las escrituras se aplican juntas (todo o nada) ----------
let txChain = Promise.resolve();
async function runTransaction(fn) {
  const run = async () => {
    const writes = []; const tx = { get: t => t.get(), set: (r, d, o) => writes.push(() => setSync(r.path, d, o)), update: (r, d) => writes.push(() => updateSync(r.path, d)), create: (r, d) => writes.push(() => createSync(r.path, d)), delete: r => writes.push(() => deleteSync(r.path)) };
    const result = await fn(tx); const mark = pendingEvents.length; sqlite.exec('BEGIN IMMEDIATE');
    try { writes.forEach(w => w()); sqlite.exec('COMMIT'); } catch (e) { sqlite.exec('ROLLBACK'); pendingEvents.length = mark; throw e; }
    return result;
  };
  const p = txChain.then(run, run); txChain = p.catch(() => {}); return p;
}
const firestore = { doc: p => new DocRef(p), collection: p => new Query(p), collectionGroup: n => new Query(n, true), runTransaction };
export const getFirestore = () => firestore;
export const backupTo = file => sqlite.exec(`VACUUM INTO '${file.replace(/'/g, "''")}'`);
