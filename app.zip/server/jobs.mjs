// Tareas programadas (equivale a Cloud Scheduler). Formato soportado: "every day HH:MM" en hora de Colombia.
const jobs = new Map(); const last = new Map();
export function setJobs(map) { jobs.clear(); for (const [k, v] of map) jobs.set(k, v); }
const bogota = () => { const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { timeZone: 'America/Bogota', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(new Date()).map(x => [x.type, x.value])); return { date: `${p.year}-${p.month}-${p.day}`, hm: `${p.hour}:${p.minute}` }; };
export const parseSchedule = s => { const m = /^every day (\d{2}):(\d{2})$/.exec(s); return m ? `${m[1]}:${m[2]}` : null; };
export async function runJob(name) { const j = jobs.get(name); if (!j) throw new Error('Tarea desconocida: ' + name); await j.run({}); }
export function startScheduler() {
  const tick = async () => { const { date, hm } = bogota(); for (const [name, j] of jobs) { if (parseSchedule(j.schedule) === hm && last.get(name) !== date) { last.set(name, date); try { await j.run({}); console.log(`[tarea] ${name} OK`); } catch (e) { console.error(`[tarea] ${name}`, e); } } } };
  return setInterval(tick, 30e3);
}
