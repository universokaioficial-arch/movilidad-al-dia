// Autenticación propia: usuarios, contraseñas (scrypt), sesiones firmadas (HS256), renovación y recuperación. Sin dependencias.
import { createHash, createHmac, randomBytes, scryptSync, timingSafeEqual, createPublicKey, verify as cverify } from 'node:crypto';
import { readFileSync, writeFileSync, existsSync, chmodSync } from 'node:fs'; import { join } from 'node:path';
import { sqlite, DATA_DIR } from './db.mjs';
const b64 = b => Buffer.from(b).toString('base64url'); const sha = s => createHash('sha256').update(s).digest('hex');
function secret() { if (process.env.JWT_SECRET) return process.env.JWT_SECRET; const f = join(DATA_DIR, 'jwt.secret'); if (!existsSync(f)) { writeFileSync(f, randomBytes(48).toString('hex')); try { chmodSync(f, 0o600); } catch { /* Windows */ } } return readFileSync(f, 'utf8'); }
const SECRET = secret(); const ACCESS_MS = 3600e3, REFRESH_MS = 30 * 864e5;
export class AuthError extends Error { constructor(code, message) { super(message); this.code = code; } }
const E = (c, m) => new AuthError(c, m);
// ----- contraseñas -----
export const hashPassword = p => { const salt = randomBytes(16); return `s1$${salt.toString('hex')}$${scryptSync(p, salt, 32, { N: 16384 }).toString('hex')}`; };
export function checkPassword(p, stored) { if (!stored) return false; const [v, s, h] = stored.split('$'); if (v !== 's1') return false; const a = scryptSync(p, Buffer.from(s, 'hex'), 32, { N: 16384 }), b = Buffer.from(h, 'hex'); return a.length === b.length && timingSafeEqual(a, b); }
// ----- sesiones -----
export function signJwt(payload) { const h = b64(JSON.stringify({ alg: 'HS256', typ: 'JWT' })), p = b64(JSON.stringify(payload)); return `${h}.${p}.${createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url')}`; }
export function verifyJwt(t) { const [h, p, s] = String(t).split('.'); if (!s) return null; const good = createHmac('sha256', SECRET).update(`${h}.${p}`).digest('base64url'); if (s.length !== good.length || !timingSafeEqual(Buffer.from(s), Buffer.from(good))) return null; try { const x = JSON.parse(Buffer.from(p, 'base64url')); return x.exp > Date.now() ? x : null; } catch { return null; } }
const rowToUser = r => r && { uid: r.uid, email: r.email, displayName: r.display_name, photoURL: r.photo, phoneNumber: r.phone, emailVerified: !!r.verified, disabled: !!r.disabled, customClaims: JSON.parse(r.claims || '{}'), validAfter: r.valid_after };
export const userById = uid => rowToUser(sqlite.prepare('SELECT * FROM users WHERE uid=?').get(uid));
export const userByEmail = e => rowToUser(sqlite.prepare('SELECT * FROM users WHERE email=?').get(String(e).trim().toLowerCase()));
export function issueTokens(uid) {
  const u = userById(uid); const now = Date.now();
  const access = signJwt({ sub: uid, email: u.email, email_verified: u.emailVerified, ...u.customClaims, iatMs: now, exp: now + ACCESS_MS });
  const refresh = randomBytes(32).toString('base64url'); sqlite.prepare('INSERT INTO refresh(hash,uid,exp) VALUES(?,?,?)').run(sha(refresh), uid, now + REFRESH_MS);
  return { access, refresh, expiresAt: now + ACCESS_MS, user: publicUser(u) };
}
export const publicUser = u => ({ uid: u.uid, email: u.email, displayName: u.displayName, photoURL: u.photoURL, emailVerified: u.emailVerified, role: u.customClaims.role ?? null });
/** Valida un token de acceso y devuelve el contexto del usuario (o null). Revisa cuenta deshabilitada y revocación. */
export function authenticate(header) {
  const t = /^Bearer (.+)$/.exec(header ?? '')?.[1]; const c = t && verifyJwt(t); if (!c) return null;
  const u = userById(c.sub); if (!u || u.disabled || c.iatMs < u.validAfter) return null;
  const { sub, email, email_verified, iatMs, exp, ...claims } = c; return { uid: sub, role: u.customClaims.role ?? '', token: { ...u.customClaims, email, email_verified }, claims };
}
export function newUid() { return 'u' + randomBytes(14).toString('hex'); }
export function createUser({ email, password, displayName = null, verified = 0, googleSub = null }) {
  email = String(email).trim().toLowerCase(); if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw E('invalid-email', 'Correo no válido.');
  if (password != null && String(password).length < 8) throw E('weak-password', 'La contraseña debe tener al menos 8 caracteres.');
  if (userByEmail(email)) throw E('email-already-in-use', 'Ese correo ya tiene cuenta.');
  const uid = newUid(); sqlite.prepare('INSERT INTO users(uid,email,pass,display_name,verified,created,google_sub) VALUES(?,?,?,?,?,?,?)').run(uid, email, password == null ? null : hashPassword(password), displayName, verified, new Date().toISOString(), googleSub); return userById(uid);
}
export function login(email, password) {
  const r = sqlite.prepare('SELECT * FROM users WHERE email=?').get(String(email).trim().toLowerCase()); const ok = r && checkPassword(String(password), r.pass); // mismo mensaje si el correo no existe
  if (!ok) throw E('invalid-credential', 'Correo o contraseña incorrectos.'); if (r.disabled) throw E('user-disabled', 'Cuenta deshabilitada.'); return issueTokens(r.uid);
}
export function refreshSession(token) {
  const h = sha(String(token)); const r = sqlite.prepare('SELECT * FROM refresh WHERE hash=?').get(h); if (!r || r.exp < Date.now()) throw E('invalid-refresh', 'Sesión vencida.');
  sqlite.prepare('DELETE FROM refresh WHERE hash=?').run(h); const u = userById(r.uid); if (!u || u.disabled) throw E('user-disabled', 'Cuenta deshabilitada.'); return issueTokens(r.uid);   // rota el refresh
}
export const logout = token => sqlite.prepare('DELETE FROM refresh WHERE hash=?').run(sha(String(token)));
// ----- tokens de un solo uso (verificación y recuperación) -----
export function makeToken(kind, uid, ms) { const t = randomBytes(32).toString('base64url'); sqlite.prepare('INSERT INTO tokens(hash,kind,uid,exp) VALUES(?,?,?,?)').run(sha(t), kind, uid, Date.now() + ms); return t; }
export function consumeToken(kind, t) { const h = sha(String(t)); const r = sqlite.prepare('SELECT * FROM tokens WHERE hash=? AND kind=?').get(h, kind); if (!r || r.exp < Date.now()) throw E('invalid-token', 'Enlace inválido o vencido.'); sqlite.prepare('DELETE FROM tokens WHERE hash=?').run(h); return r.uid; }
export const markVerified = uid => sqlite.prepare('UPDATE users SET verified=1 WHERE uid=?').run(uid);
export function setPassword(uid, password) { if (String(password).length < 8) throw E('weak-password', 'La contraseña debe tener al menos 8 caracteres.'); sqlite.prepare('UPDATE users SET pass=? WHERE uid=?').run(hashPassword(password), uid); revokeRefreshTokens(uid); }
export function revokeRefreshTokens(uid) { sqlite.prepare('UPDATE users SET valid_after=? WHERE uid=?').run(Date.now(), uid); sqlite.prepare('DELETE FROM refresh WHERE uid=?').run(uid); }
// ----- Google (token de identidad verificado con las claves públicas de Google) -----
let jwks = { at: 0, keys: [] };
export async function verifyGoogleIdToken(idToken, clientId) {
  if (!clientId) throw E('google-not-configured', 'Falta GOOGLE_CLIENT_ID en el servidor.');
  const [h, p, s] = String(idToken).split('.'); if (!s) throw E('invalid-token', 'Token inválido.'); const header = JSON.parse(Buffer.from(h, 'base64url')), c = JSON.parse(Buffer.from(p, 'base64url'));
  if (Date.now() - jwks.at > 3600e3) { const r = await fetch('https://www.googleapis.com/oauth2/v3/certs'); jwks = { at: Date.now(), keys: (await r.json()).keys }; }
  const jwk = jwks.keys.find(k => k.kid === header.kid); if (!jwk || header.alg !== 'RS256') throw E('invalid-token', 'Clave no reconocida.');
  if (!cverify('RSA-SHA256', Buffer.from(`${h}.${p}`), createPublicKey({ key: jwk, format: 'jwk' }), Buffer.from(s, 'base64url'))) throw E('invalid-token', 'Firma inválida.');
  if (c.aud !== clientId || !['accounts.google.com', 'https://accounts.google.com'].includes(c.iss) || c.exp * 1000 < Date.now() || !c.email_verified) throw E('invalid-token', 'Token de Google no válido.');
  return c;
}
export function loginWithGoogle(c) {
  const bySub = sqlite.prepare('SELECT uid FROM users WHERE google_sub=?').get(c.sub); let u = bySub ? userById(bySub.uid) : userByEmail(c.email);
  if (!u) u = createUser({ email: c.email, password: null, displayName: c.name ?? null, verified: 1, googleSub: c.sub });
  else sqlite.prepare('UPDATE users SET google_sub=?, verified=1 WHERE uid=?').run(c.sub, u.uid);
  if (u.disabled) throw E('user-disabled', 'Cuenta deshabilitada.'); return issueTokens(u.uid);
}
// ----- API tipo Admin SDK (la usan las funciones existentes) -----
export const adminAuth = {
  async getUser(uid) { const u = userById(uid); if (!u) throw Object.assign(new Error('Usuario no encontrado'), { code: 'auth/user-not-found' }); return u; },
  async getUserByEmail(e) { const u = userByEmail(e); if (!u) throw Object.assign(new Error('Usuario no encontrado'), { code: 'auth/user-not-found' }); return u; },
  async setCustomUserClaims(uid, claims) { sqlite.prepare('UPDATE users SET claims=? WHERE uid=?').run(JSON.stringify(claims ?? {}), uid); },
  async revokeRefreshTokens(uid) { revokeRefreshTokens(uid); },
  async updateUser(uid, p) {
    if (p.email !== undefined) sqlite.prepare('UPDATE users SET email=? WHERE uid=?').run(String(p.email).toLowerCase(), uid);
    if (p.displayName !== undefined) sqlite.prepare('UPDATE users SET display_name=? WHERE uid=?').run(p.displayName, uid);
    if (p.photoURL !== undefined) sqlite.prepare('UPDATE users SET photo=? WHERE uid=?').run(p.photoURL, uid);
    if (p.phoneNumber !== undefined) sqlite.prepare('UPDATE users SET phone=? WHERE uid=?').run(p.phoneNumber, uid);
    if (p.disabled !== undefined) sqlite.prepare('UPDATE users SET disabled=? WHERE uid=?').run(p.disabled ? 1 : 0, uid);
    if (p.providersToUnlink?.includes('google.com')) sqlite.prepare('UPDATE users SET google_sub=NULL WHERE uid=?').run(uid);
    return userById(uid);
  },
};
// ----- correo (verificación y recuperación) -----
export async function sendMail({ to, subject, text }) {
  if ((process.env.MAIL_DRIVER ?? 'console') === 'resend') {
    const r = await fetch('https://api.resend.com/emails', { method: 'POST', headers: { Authorization: `Bearer ${process.env.RESEND_API_KEY}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ from: process.env.MAIL_FROM, to, subject, text }) });
    if (!r.ok) throw new Error('Resend respondió ' + r.status);
  } else console.log(`[correo → ${to}] ${subject}\n${text}`);   // modo desarrollo: el enlace sale en el registro del servidor
}
